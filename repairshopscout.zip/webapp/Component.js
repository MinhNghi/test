sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"atudoboilerplate/model/models"
], function(UIComponent, Device, models) {
	"use strict";

	return UIComponent.extend("atudoboilerplate.Component", {

		metadata: {
			manifest: "json"
		},

		init: function() {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// set the device model
			this.setModel(models.createDeviceModel(), "device");

			// set debug flag
			var oDebugModel = new sap.ui.model.json.JSONModel();
			oDebugModel.setData({
				debug: false
			});
			sap.ui.getCore().setModel(oDebugModel, "debug");
		
			// initialize the Router, navigate to targets
			this.getRouter().initialize();
		}
	});
});