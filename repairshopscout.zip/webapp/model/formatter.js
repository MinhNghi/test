sap.ui.define([
	"sap/ui/core/format/NumberFormat"
	], function(NumberFormat) {
	"use strict";

	return {
		//Formats an address to a static google maps image
		formatMapUrl: function(sStreet, sCity) {
			return "https:" + "//maps.googleapis.com/maps/api/staticmap?zoom=15&size=550x550&scale=2&markers=" + jQuery.sap.encodeURL(sStreet +
				" " + sCity);
		},

		distance: function(sDistance) {
			var result;
			var oNumberFormat = NumberFormat.getFloatInstance({
				minFractionDigits: 2,
				maxFractionDigits: 2
			});
			if (sDistance === "0") {
				result = "";
			} else {
				result = oNumberFormat.format(sDistance) + " km";
			}
			return result;
		},

		rating: function(Review_Value) {
			var result;
			switch (Review_Value) {
				case 1:
					result = "Sehr schlecht";
					break;
				case 2:
					result = "Schlecht";
					break;
				case 3:
					result = "Normal";
					break;
				case 4:
					result = "Gut";
					break;
				case 5:
					result = "Sehr gut";
					break;
			}
			return result;
		}

	};

});