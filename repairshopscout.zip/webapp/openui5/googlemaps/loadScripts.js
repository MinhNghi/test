sap.ui.define(["jquery.sap.global", "openui5/googlemaps/ScriptsUtil"], function(a, e) {
	"use strict";
	var l = function() {
		var e = {};
		return e.defaultUrl = location.protocol.replace("file", "https") + "//maps.google.com/maps/api/js?sensor=false&callback=initialize", e.notifyEvent =
			"google.maps.loaded", e.callbackName = "google.maps.callBack", e.isLoaded = new Promise(function(a) {
				e.callBack = function() {
					this.loaded = !0, sap.ui.getCore().getEventBus().publish(this.notifyEvent), a();
				};
			}), e.load = function(e) {
				var l = {},
					o = e.getParams(),
					i = o.url ? o.url : this.defaultUrl;
				a.sap.endsWith(i, "?") || (i += "?"), o.v && (l.v = o.v), l.sensor = o.sensor || !0, o.libraries && (l.libraries = o.libraries), o.language &&
					(l.language = o.language), o.key && (l.key = o.key), l.callback = this.callbackName;
				var s = i.concat(a.param(l));
				a.sap.includeScript(s, "google.maps", null, null);
			}, e;
	}();
	return l.load(e), l;
}, !0);