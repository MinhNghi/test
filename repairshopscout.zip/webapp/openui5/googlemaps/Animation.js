sap.ui.define("openui5/googlemaps/Animation", ["jquery.sap.global"], function() {
	"use strict";
	var e = {
		BOUNCE: 1,
		DROP: 2,
		k: 3,
		j: 4
	};
	return e;
}, !0);