sap.ui.define(["jquery.sap.global", "sap/ui/core/Control", "google.maps", "./MapUtils"], function(t, e, i, o) {
	"use strict";
	var s = e.extend("openui5.googlemaps.Polyline", {
		metadata: {
			properties: {
				strokeColor: {
					type: "sap.ui.core.CSSColor",
					group: "Appearance",
					defaultValue: null
				},
				strokeOpacity: {
					type: "float"
				},
				strokeWeight: {
					type: "float"
				},
				icons: {
					type: "object"
				},
				path: {
					type: "object",
					bindable: "bindable"
				},
				visible: {
					type: "boolean",
					bindable: "bindable",
					defaultValue: !0
				},
				draggable: {
					type: "boolean"
				}
			},
			renderer: {}
		}
	});
	return s.prototype.setVisible = function(t) {
		this.setProperty("visible", t, !0), this.polyline && this.polyline.setVisible(this.getVisible());
	}, s.prototype.parsePath = function() {
		var t = [];
		return this.getPath() && this.getPath().forEach(function(e) {
			t.push(o.objToLatLng(e));
		}), t;
	}, s.prototype.createPolyline = function() {
		this.polyline || (this.polyline = new i.Polyline), this.polyline.setMap(this.map), this.polyline.setOptions(this.getOptions());
	}, s.prototype.getOptions = function() {
		var t = {};
		return t.path = this.parsePath(), t.strokeColor = this.getStrokeColor(), t.strokeOpacity = this.getStrokeOpacity(), t.strokeWeight =
			this.getStrokeWeight(), t.visible = this.getVisible(), t.draggable = this.getDraggable(), t.icons = this.getIcons(), t;
	}, s.prototype._mapRendered = function(t) {
		this.map = t, this.createPolyline();
	}, s.prototype.reset = function() {
		this.map = void 0, this.polyline && this.polyline.setMap(null);
	}, s.prototype.exit = function() {
		this.reset();
	}, s;
}, !0);