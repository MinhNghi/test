sap.ui.define("openui5/googlemaps/UnitSystem", ["jquery.sap.global"], function() {
	"use strict";
	var e = {
		IMPERIAL: 1,
		METRIC: 0
	};
	return e;
}, !0);