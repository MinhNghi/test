sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/model/json/JSONModel",
	"atudoboilerplate/controller/LoginDialog",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox",
	"atudoboilerplate/controller/BaseCRSController"
], function(UIComponent, JSONModel, LoginDialog, Filter, FilterOperator, MessageBox, BaseCRSController) {
	"use strict";
	return BaseCRSController.extend("atudoboilerplate.controller.Home", {

		onInit: function() {
			var oVbox = this.getView().byId("vbox");
			var locations = [{
				id: 0,
				place: "Hamburg",
				longitude: 9.993682,
				latitude: 53.551086
			}, {
				id: 1,
				place: "München",
				longitude: 11.576124,
				latitude: 48.137154
			}, {
				id: 2,
				place: "Berlin",
				longitude: 13.377775,
				latitude: 52.516266
			}, {
				id: 3,
				place: "Conrad",
				longitude: 10.0803311,
				latitude: 53.5729074
			}, {
				id: 4,
				place: "Harburg",
				longitude: 9.9673451,
				latitude: 53.4619107
			}, {
				id: 5,
				place: "Grönwold",
				longitude: 10.4095544,
				latitude: 53.6391297
			}];
			var oViewModel = new JSONModel(locations);
			var oItemTemplate = new sap.ui.core.Item({
				text: "{place}"
			});
			var oSelect = new sap.m.Select(this.createId("location"), {
				items: {
					path: "/",
					template: oItemTemplate
				}
			});
			oSelect.setModel(oViewModel);
			oVbox.addItem(oSelect);

			this.loginDialog = new LoginDialog();
			//$.sap.require("jquery.sap.storage");
			//$.sap.storage($.sap.storage.Type.local).removeAll();
		},

		onAtudoPress: function() {
			var oView = this.getView();
			var oSelect = oView.byId("location");
			var oUserSelect = oView.byId("cbUser");
			var sText = oUserSelect.getSelectedItem().getAdditionalText().split(";");
			var sEmail = sText[0];
			var sToken = sText[1];
			var sAtuid = sText[2];
			//sAtuid = undefined; // EB for test
			var sHeading = "1";
			var sOS = "android";
			var oItem = oSelect.getSelectedItem();
			var oContext = oItem.getBindingContext();
			var sLat = oContext.getProperty("latitude");
			var sLng = oContext.getProperty("longitude");
			var oDialog = this.loginDialog._getDialog();
			if (oDialog !== undefined) {
				var oLoginModel = oDialog.getModel("cred");
				if (oLoginModel !== undefined) {
					var oLoginData = oLoginModel.getData();
					sAtuid = oLoginData.atuid;
					sEmail = oLoginData.email;
					sToken = oLoginData.password;
					oDialog.setModel(null, "cred");
				}
			}

			//Set debug flag to local storage.
			jQuery.sap.require("jquery.sap.storage");
			var oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.local);
			oStorage.put("debugFlag", true);
			oStorage.put("counterCall", 0);
			var oDebugModel = sap.ui.getCore().getModel("debug");
			var oDebugData = oDebugModel.getData();
			oDebugData.debug = true;
			sap.ui.getCore().setModel(oDebugModel, "debug");

			UIComponent.getRouterFor(this).navTo("LocateRepairShops", {
				email: sEmail,
				token: sToken,
				lat: sLat,
				lng: sLng,
				heading: sHeading,
				os: sOS,
				atuid: sAtuid
			});
		},

		onLoginDialog: function(evt) {
			this.loginDialog.open(this.getView());
		}
	});

});