sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/UIComponent",
	"sap/ui/core/routing/History",
	"atudoboilerplate/controller/BaseCRSController"
], function(Controller, UIComponent, History, BaseCRSController) {
	"use strict";

	return BaseCRSController.extend("atudoboilerplate.controller.Message", {
		onHomePress: function() {
			UIComponent.getRouterFor(this).navTo("Home");
		},
		onClose: function() {
			var oGeneralModel = sap.ui.getCore().getModel("general");
			var oGeneralData = oGeneralModel.getData();
			UIComponent.getRouterFor(this).navTo("RepairShopDetail", {
				lat: oGeneralData.lat,
				lng: oGeneralData.lng,
				Id: this.crsid,
				Id_user: oGeneralData.id_user,
				Distance: oGeneralData.distance,
				email: oGeneralData.email
			});
		},
		onInit: function() {
			UIComponent.getRouterFor(this).getRoute("Message").attachPatternMatched(this._onObjectMatched, this);
		},

		_onObjectMatched: function(oEvent) {
			var oI18n = this.getView().getModel("i18n").getResourceBundle();
			var sTitle,
				sHeader,
				sItem;
			var args = oEvent.getParameter("arguments");
			var txtTitle = this.getView().byId("txtTitle");
			var txtHeader = this.getView().byId("txtHeader");
			var txtItem = this.getView().byId("txtItem");
			this.crsid = args.crsid;
			this.action = args.action;
			this._showhideHomeButton();
			switch (this.action) {
				case "Review":
					sTitle = oI18n.getText("textTitleReview.message");
					sHeader = oI18n.getText("textHeaderReview.message");
					sItem = oI18n.getText("textItemReview.message");
					txtTitle.setText(sTitle);
					txtHeader.setText(sHeader);
					txtItem.setText(sItem);
					break;
				case "ReCall":
					sTitle = oI18n.getText("textTitleRCall.message");
					sHeader = oI18n.getText("textHeaderRCall.message");
					sItem = oI18n.getText("textItemRCall.message");
					txtTitle.setText(sTitle);
					txtHeader.setText(sHeader);
					txtItem.setText(sItem);
					break;
				case "EditShop":
					sTitle = oI18n.getText("textTitleEdit.message");
					sHeader = oI18n.getText("textHeaderEdit.message");
					sItem = oI18n.getText("textItemEdit.message");
					txtTitle.setText(sTitle);
					txtHeader.setText(sHeader);
					txtItem.setText(sItem);
					break;
			}
		}

	});

});