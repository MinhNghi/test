sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/UIComponent",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Sorter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox",
	"atudoboilerplate/model/formatter",
	"atudoboilerplate/controller/BaseCRSController"
], function(Controller, UIComponent, JSONModel, Sorter, Filter, FilterOperator, MessageBox, formatter, BaseCRSController) {
	"use strict";

	return BaseCRSController.extend("atudoboilerplate.controller.FavoriteRepairShops", {
		formatter: formatter,
		onInit: function() {
			var oComponent = this.getOwnerComponent();
			this.oModel = oComponent.getModel("rs");

			UIComponent.getRouterFor(this).getRoute("FavoriteRepairShops").attachPatternMatched(this._onObjectMatched, this);
		},

		onDetailPress: function(event) {
			this._showObject(event.getSource());
		},

		handleCancel: function(event) {
			this._getLocateDialog().close();
		},
		handleSortPress: function(event) {
			UIComponent.getRouterFor(this).navTo("Settings", {
				email: this.email,
				lat: this.lat,
				lng: this.lng
			});
		},
		
		_showObject: function(oItem) {
			//Set value of UserId to oModel.oMetadata.sUser, this values will be used when user review the RepairShop
			var oContext = oItem.getBindingContext("rs");
			var oModel = oContext.getModel();
			var sUserId = oItem.getBindingContext("rs").getProperty("UserId");
			oModel.oMetadata.sUser = sUserId;
			
			// Navigate to CRS Detail page
			this.CRSId = oItem.getBindingContext("rs").getProperty("CRSId");
			this.Id_user = sUserId;
			this.distance = oItem.getBindingContext("rs").getProperty("Distance");
			this.onNavDetail();
		},

		_onObjectMatched: function(oEvent) {
			// Set all parameters of query to variables to use in next pages.
			var args = oEvent.getParameter("arguments");
			this.email = args.email;
			this.lng = args.lng;
			this.lat = args.lat;
			this.Id_user = args.Id_user;
			this._addListItems(oEvent);
			this._showhideHomeButton();
			//Disable button favorite
			this.getView().byId("btnFavorite").setEnabled(false);
		},

		_addListItems: function(event) {
			var that = this;
			var oView = this.getView();
			var filters = [];
			filters.push(new Filter("Longitude", FilterOperator.EQ, this.lng));
			filters.push(new Filter("Latitude", FilterOperator.EQ, this.lat));
			filters.push(new Filter("UserId", FilterOperator.EQ, this.Id_user));
			filters.push(new Filter("Favorite", FilterOperator.EQ, "true"));
			jQuery.sap.require("sap.ui.core.format.NumberFormat");

			var oList = oView.byId("repairShopList");
			oList.setModel(this.oModel);
			var oBinding = oList.getBinding("items");
			oBinding.filter(filters);
			oList.addEventDelegate({
				onAfterRendering: function() {
					that._setIcon();
				}
			}, this);
			
			var oSettingsModel = sap.ui.getCore().getModel("settings");
			if (oSettingsModel !== undefined && oSettingsModel !== null) {
				var oSettingsData = oSettingsModel.getData();
				filters.push(new Filter("Type", FilterOperator.EQ, oSettingsData.Type));
				oBinding.filter(filters);
				// Sorting
				this._oSorter = new Sorter({
					path: oSettingsData.Path,
					descending: oSettingsData.Descending
				});
				oBinding.sort(this._oSorter);
			}
			
			oBinding.getModel().updateBindings();

		}

	});

});