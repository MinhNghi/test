sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/UIComponent",
	"sap/ui/core/routing/History",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"atudoboilerplate/controller/BaseCRSController"
], function(Controller, UIComponent, History, Filter, FilterOperator, BaseCRSController) {
	"use strict";

	return BaseCRSController.extend("atudoboilerplate.controller.RepairShopAppointment", {
		onInit: function() {
			UIComponent.getRouterFor(this).getRoute("RepairShopAppointment").attachPatternMatched(this._onObjectMatched, this);
		},
		
		onPanelNews: function(event) {
			var oPanel = this.byId("panelNews");
			var oBtnPanel = this.byId("btnNewsPanel");
			var isVisible = oPanel.getVisible();
			if (isVisible === true) {
				oPanel.setVisible(false);
				oBtnPanel.setIcon("sap-icon://navigation-up-arrow");
			} else {
				oPanel.setVisible(true);
				oBtnPanel.setIcon("sap-icon://navigation-down-arrow");
			}
		},
		
		onPanelUpcoming: function(event) {
			var oPanel = this.byId("panelUpcoming");
			var oBtnPanel = this.byId("btnUpcomingPanel");
			var isVisible = oPanel.getVisible();
			if (isVisible === true) {
				oPanel.setVisible(false);
				oBtnPanel.setIcon("sap-icon://navigation-up-arrow");
			} else {
				oPanel.setVisible(true);
				oBtnPanel.setIcon("sap-icon://navigation-down-arrow");
			}
		},
		
		onPanelPast: function(event) {
			var oPanel = this.byId("panelPast");
			var oBtnPanel = this.byId("btnPastPanel");
			var isVisible = oPanel.getVisible();
			if (isVisible === true) {
				oPanel.setVisible(false);
				oBtnPanel.setIcon("sap-icon://navigation-up-arrow");
			} else {
				oPanel.setVisible(true);
				oBtnPanel.setIcon("sap-icon://navigation-down-arrow");
			}
		},

		_onObjectMatched: function(oEvent) {
			//Disable button appointment
			this.getView().byId("btnAppointment").setEnabled(false);
			var that = this;
			var args = oEvent.getParameter("arguments");
			this.email = args.email;
			this.Id_user = args.Id_user;
			this.lat = args.lat;
			this.lng = args.lng;
			this._showhideHomeButton();
			var oModel = this.getView().getModel("rs");
			var oAppointFilter = [];
			oAppointFilter.push(new Filter("Id_User", FilterOperator.EQ, this.Id_user));
			oModel.read("/CRS_AppointmentSet", {
				filters: oAppointFilter,
				success: function(oAppointData) {
					var i, j, k,
						obj;
					var upcomingList = [];
					var pastList = [];
					var newsList = [];
					var oNewsList = that.getView().byId("newsAppointList");
					var oUpcomingList = that.getView().byId("upcomingAppointList");
					var oPastList = that.getView().byId("pastAppointList");
					for (i = 0; i < oAppointData.results.length; i++) {
						obj = oAppointData.results[i];
						if (obj.Type !== "n" && obj.Type !== "a") {
							continue;
						}
						if (obj.Status !== "o") {
							continue;
						}
						var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
							pattern: "yyyyMMdd HH:mm"
						});
						var oDate = oDateFormat.format(obj.Next_Contact);
						var dDate = new Date();
						var oDateToday = oDateFormat.format(dDate);

						if (oDate >= oDateToday) {
							switch (obj.Type) {
								case "n":
									upcomingList.push({
										Event: obj.Event,
										DateTime: oDate,
										Next_Contact: obj.Next_Contact,
										CRSId: obj.CRSId,
										Name: "",
										Address: "",
										Telephone: ""
									});
									break;
								case "a":
									newsList.push({
										Event: obj.Event,
										DateTime: oDate,
										Next_Contact: obj.Next_Contact,
										CRSId: obj.CRSId,
										Name: "",
										Address: "",
										Telephone: ""
									});
									break;
							}
						} else {
							pastList.push({
								Event: obj.Event,
								DateTime: oDate,
								Next_Contact: obj.Next_Contact,
								CRSId: obj.CRSId,
								Name: "",
								Address: "",
								Telephone: ""
							});
						}

						// Check if appointment without CRSId, not need to show data Shop
						if (obj.CRSId === "" || obj.CRSId === " " || obj.CRSId === "0") {
							continue;
						}

						oModel.read("/CRS_DataSet(CRSId=" + obj.CRSId + ",Version=0)", {
							success: function(oShopData) {
								var oDataNews = oNewsList.getModel().getData();
								var oDataUpcoming = oUpcomingList.getModel().getData();
								var oDataPast = oPastList.getModel().getData();
								for (i = 0; i < upcomingList.length; i++) {
									if (upcomingList[i].CRSId === oShopData.CRSId) {
										oDataUpcoming.appointment[i].Name = oShopData.Name;
										oDataUpcoming.appointment[i].Address = oShopData.Street + "-" + oShopData.City;
										oDataUpcoming.appointment[i].Telephone = oShopData.FixedPhone;
										oDataUpcoming.appointment[i].Distance = oShopData.Distance;
									}
								}
								for (j = 0; j < pastList.length; j++) {
									if (pastList[j].CRSId === oShopData.CRSId) {
										oDataPast.appointment[j].Name = oShopData.Name;
										oDataPast.appointment[j].Address = oShopData.Street + "-" + oShopData.City;
										oDataPast.appointment[j].Telephone = oShopData.FixedPhone;
										oDataPast.appointment[j].Distance = oShopData.Distance;
									}
								}
								for (k = 0; k < newsList.length; k++) {
									if (newsList[k].CRSId === oShopData.CRSId) {
										oDataNews.appointment[k].Name = oShopData.Name;
										oDataNews.appointment[k].Address = oShopData.Street + "-" + oShopData.City;
										oDataNews.appointment[k].Telephone = oShopData.FixedPhone;
										oDataNews.appointment[k].Distance = oShopData.Distance;
									}
								}
								oNewsList.getModel().setData(oDataNews);
								oUpcomingList.getModel().setData(oDataUpcoming);
								oPastList.getModel().setData(oDataPast);
							}
						});
					}

					var oJsonModelNews = new sap.ui.model.json.JSONModel({
						appointment: newsList
					});

					var oJsonModelUpcoming = new sap.ui.model.json.JSONModel({
						appointment: upcomingList
					});

					var oJsonModelPast = new sap.ui.model.json.JSONModel({
						appointment: pastList
					});
					oNewsList.setModel(oJsonModelNews);
					oUpcomingList.setModel(oJsonModelUpcoming);
					oPastList.setModel(oJsonModelPast);

					// Hide CRS info and telephone.
					var sViewId = that.getView().getId();
					var sUpcomingListId = oUpcomingList.getId();
					var sNewsListId = oNewsList.getId();
					var sPastListId = oPastList.getId();
					var sTxtCRS,
						stxtTelephone;
					for (i = 0; i < upcomingList.length; i++) {
						if (upcomingList[i].CRSId === "" || upcomingList[i].CRSId === " " || upcomingList[i].CRSId === "0") {
							sTxtCRS = sViewId + "--txtCRSUpcoming-" + sUpcomingListId + "-" + i;
							stxtTelephone = sViewId + "--txtTelephoneUpcoming-" + sUpcomingListId + "-" + i;
							that.getView().byId(sTxtCRS).setVisible(false);
							that.getView().byId(stxtTelephone).setVisible(false);
						}
					}
					for (j = 0; j < pastList.length; j++) {
						if (pastList[j].CRSId === "" || pastList[j].CRSId === " " || pastList[j].CRSId === "0") {
							sTxtCRS = sViewId + "--txtCRSPast-" + sPastListId + "-" + j;
							stxtTelephone = sViewId + "--txtTelephonePast-" + sPastListId + "-" + j;
							that.getView().byId(sTxtCRS).setVisible(false);
							that.getView().byId(stxtTelephone).setVisible(false);
						}
					}
					for (k = 0; k < newsList.length; k++) {
						if (newsList[k].CRSId === "" || newsList[k].CRSId === " " || newsList[k].CRSId === "0") {
							sTxtCRS = sViewId + "--txtCRSNews-" + sNewsListId + "-" + k;
							stxtTelephone = sViewId + "--txtTelephoneNews-" + sNewsListId + "-" + k;
							that.getView().byId(sTxtCRS).setVisible(false);
							that.getView().byId(stxtTelephone).setVisible(false);
						}
					}
				},
				error: function(oError) {}
			});
		},
		
		onPressDetailShop: function(event) {
			this.CRSId = event.getSource().getTarget();
			var oModel = this.getView().getModel("rs");
			var sPath = "/CRS_FindSet(CRSId=" + this.CRSId + "m,UserId=" + this.Id_user + "m)";
			var oData = oModel.getProperty(sPath);
			if (this.CRSId === "N/A" || this.CRSId === "0") {
				return;
			}
			if (oData === undefined) {
				this.distance = 0;
			} else {
				this.distance = oData.Distance;
			}
			
			// Navigate to CRS Detail
			this.onNavDetail();
		}

	});

});