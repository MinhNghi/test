sap.ui.define([
    "sap/ui/base/Object",
    "sap/m/MessageBox"
], function (UI5Object, MessageBox) {
    "use strict";

    return UI5Object.extend("atudoboilerplate.controller.ErrorHandler", {
        /**
         * Handles application errors by automatically attaching to the model
         * events and displaying errors when needed.
         * 
         * @class
         * @param {sap.ui.core.UIComponent} oComponent reference to the app's component
         * @public
         * @alias atudoboilerplate.controller.ErrorHandler
         */
        constructor: function (oComponent, aModelName) {
        	// indicate currently a message is shown
        	this._bMessageOpen = false;
        	
        	// get some component data
        	this._oComponent = oComponent;
        	this._oResourceBundle = oComponent.getModel("i18n").getResourceBundle();
        	
        	this._sErrorText = this._oResourceBundle.getText("errorText");
        	
        	if(aModelName.length) {
        		aModelName.forEach(function(item){
        			var oModel = oComponent.getModel(item);
        			oModel.attachRequestFailed(function (oEvent) {
		                var oParams = oEvent.getParameters();
		                if (oParams.response.statusCode === 400) {
		                    this._showAuthError(oParams.response, oParams.url);
		                }
		                // skip 404 errors
		                else if (oParams.response.statusCode !== "404"
		                	|| (oParams.response.statusCode === 404 && oParams.response.responseText.indexOf("Cannot POST") === 0)) {
		                    this._showServiceError(oParams.response);
		                }
		           }, this);
        		});
        	}
        	else {
        		this._oModel = oComponent.getModel();
        		this._oModel.attachMetadataFailed(function (oEvent) {
	                var oParams = oEvent.getParameters();
	                this._showMetadataError(oParams.response);
	            }, this);
	
	            this._oModel.attachRequestFailed(function (oEvent) {
	                var oParams = oEvent.getParameters();
	                if (oParams.response.statusCode === 400) {
	                    this._showAuthError(oParams.response, oParams.url);
	                }
	                // skip 404 errors
	                else if (oParams.response.statusCode !== "404"
	                	|| (oParams.response.statusCode === 404 && oParams.response.responseText.indexOf("Cannot POST") === 0)) {
	                    this._showServiceError(oParams.response);
	                }
	           }, this);
        	}
        },
        /**
         * Shows a {@link sap.m.MessageBox} when the metadata call has failed.
         * The user can try to refresh the metadata.
         * 
         * @param {string} sDetails a technical error to be displayed on request
         * @private
         */
        _showMetadataError: function (sDetails) {
            MessageBox.error(
                this._sErrorText,
            {
                id: "metadataErrorMessageBox",
                details: sDetails,
                styleClass: this._oComponent.getContentDensityClass(),
                actions: [MessageBox.Action.RETRY, MessageBox.Action.CLOSE],
                onClose: function (sAction) {
                    if (sAction === MessageBox.Action.RETRY) {
                        this._oModel.refreshMetadata();
                    }
                }.bind(this)
            });
        },
        /**
         * Shows a {@link sap.m.MessageBox} when a service call has failed.
         * Only the first error message will be display.
         * 
         * @param {string} sDetails a technical error to be displayed on request
         * @private
         */
        _showServiceError: function (sDetails) {
            if (this._bMessageOpen) {
                return;
            }
            this._bMessageOpen = true;
            MessageBox.error(
                this._sErrorText,
            {
                id: "serviceErrorMessageBox",
                details: sDetails,
                styleClass: this._oComponent.getContentDensityClass(),
                actions: [MessageBox.Action.CLOSE],
                onClose: function () {
                    this._bMessageOpen = false;
                }.bind(this)
            });
        },
        /**
         * Shows a {@link sap.m.MessageBox} when a service call has failed.
         * Only the first error message will be display.
         * 
         * @param {string} sDetails a technical error to be displayed on request
         * @param {string} sUrl complete requested url
         * @private
         */
        _showAuthError: function (sDetails, sUrl) {
            var sErrorText = this._oResourceBundle.getText("errorAuthText", sUrl.match(/\/([^\/]+)\/?$/)[1]);
            if (this._bMessageOpen) {
                return;
            }
            this._bMessageOpen = true;
            MessageBox.error(
                sErrorText,
            {
                id: "authErrorMessageBox",
                title: "Gehtnix, Feierabend!",
                icon: sap.m.MessageBox.Icon.INFORMATION,
                details: sDetails,
                styleClass: this._oComponent.getContentDensityClass(),
                actions: [MessageBox.Action.CLOSE],
                onClose: function () {
                    this._bMessageOpen = false;
                }.bind(this)
            });
        }
    });
});/*global sap */