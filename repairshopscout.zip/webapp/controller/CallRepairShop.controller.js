sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"sap/m/MessageBox",
	"sap/ui/model/SimpleType",
	"atudoboilerplate/model/formatter",
	"atudoboilerplate/controller/BaseCRSController"
], function(UIComponent, JSONModel, History, MessageBox, SimpleType, formatter, BaseCRSController) {
	"use strict";

	return BaseCRSController.extend("atudoboilerplate.controller.CallRepairShop", {
		formatter: formatter,
		onInit: function() {
			var iOriginalBusyDelay,
				oViewModel = new JSONModel({
					busy: true,
					delay: 0,
					all: 0,
					positive: 0,
					critical: 0
				});
			this.getRouter().getRoute("CallRepairShop").attachPatternMatched(this._onObjectMatched, this);
			// Store original busy indicator delay, so it can be restored later on
			iOriginalBusyDelay = this.getView().getBusyIndicatorDelay();
			this.setModel(oViewModel, "objectView");
			this.getOwnerComponent().getModel("rs").metadataLoaded().then(function() {
				// Restore original busy indicator delay for the object view
				oViewModel.setProperty("/delay", iOriginalBusyDelay);
			});
		},

		onClose: function() {
			var oGeneralModel = sap.ui.getCore().getModel("general");
			var oGeneralData = oGeneralModel.getData();
			UIComponent.getRouterFor(this).navTo("RepairShopDetail", {
				lat: oGeneralData.lat,
				lng: oGeneralData.lng,
				Id: this.crsid,
				Id_user: oGeneralData.id_user,
				Distance: oGeneralData.distance,
				email: oGeneralData.email
			});
		},

		_onObjectMatched: function(oEvent) {
			this.lat = oEvent.getParameter("arguments").lat;
			this.lng = oEvent.getParameter("arguments").lng;
			this.crsid = oEvent.getParameter("arguments").CRSId;
			this.oGeneralModel = sap.ui.getCore().getModel("general");
			var oGeneralData = this.oGeneralModel.getData();
			this.email = oGeneralData.email;
			this.Id_user = oEvent.getParameter("arguments").UserId;
			this.distance = formatter.distance(oGeneralData.distance);
			this._showhideHomeButton();
			this.getModel("rs").metadataLoaded().then(function() {
				var sObjectPath = this.getModel("rs").createKey("CRS_DataSet", {
					CRSId: this.crsid,
					Version: 0
				});
				this._bindView("rs>/" + sObjectPath);
			}.bind(this));
		},

		_bindView: function(sObjectPath) {
			this.getView().byId("txtDistance").setText(this.distance);
			var oViewModel = this.getModel("objectView"),
				oDataModel = this.getModel("rs");
			var that = this;
			this.getView().bindElement({
				path: sObjectPath,
				events: {
					change: this._onBindingChange.bind(this),
					dataRequested: function() {
						oDataModel.metadataLoaded().then(function() {
							oViewModel.setProperty("/busy", true);
						});
					},
					dataReceived: function() {
						oViewModel.setProperty("/busy", false);
					}
				}
			});

			// Read data Car Repair Shop Favorite
			var oModel = this.getModel("rs");
			var sFavoritenPath = "/CRS_FavoritenSet(CRSID=" + this.crsid + ",id_User=" + this.Id_user + ")";
			oModel.read(sFavoritenPath, {
				success: function(oData, response) {
					that._setLikeDislike(oData.Type_Favo);
				},
				error: function(oError) {
					that._setLikeDislike("");
				}
			});
		},

		_onBindingChange: function() {
			var oViewModel = this.getModel("objectView");
			oViewModel.setProperty("/busy", false);
		},

		handleRecall: function(event) {
			UIComponent.getRouterFor(this).navTo("CallbackRepairShop", {
				CRSId: this.crsid,
				UserId: this.Id_user,
				lat: this.lat,
				lng: this.lng
			});
		},

		handleCallDirect: function(event) {
			// Create a CRS Log with type d
			var oProperties = {
				Type: "d",
				Status: "n",
				Id_User: this.Id_user,
				CRSId: this.crsid,
				Longitude: this.lng.toString(),
				Latitude: this.lat.toString(),
				Event: "CRS was direct call."
			};
			this.createCRSLog(oProperties);
			
			// Open a standard call app with phone number of shop
			var oObject = this.getView().getBindingContext("rs").getObject();
			//var sTel = "//" + oObject.FixedPhone;
			var sTel = oObject.FixedPhone;
			sap.m.URLHelper.triggerTel(sTel);
		}
	});
});