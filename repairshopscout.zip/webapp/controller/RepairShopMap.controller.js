sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/UIComponent",
	"openui5/googlemaps/MapUtils",
	"sap/ui/core/routing/History",
	"google.maps",
	"atudoboilerplate/controller/BaseCRSController"
], function(Controller, UIComponent, util, History, googlemaps, BaseCRSController) {
	"use strict";

	return BaseCRSController.extend("atudoboilerplate.controller.RepairShopMap", {
		onInit: function() {
			UIComponent.getRouterFor(this).getRoute("RepairShopMap").attachPatternMatched(this._onObjectMatched, this);
		},

		onNavigateToShop: function(event) {
			var sDestination = "atudo://service:navigation/destination:" + this.shop_lat + "," + this.shop_lng;
			sap.m.URLHelper.redirect(sDestination);
			/*this.byId("mapDirection").setVisible(true);
			this.byId("mapMarker").setVisible(false);
			var oModel = this.getView().getModel("map");
			var oContext = oModel.getContext("/places/0/");
			var oPos = this._getLocation(this);
			var geoLocation = util.geocodePosition(oPos);
			geoLocation.done(this._updateLocation.bind(this));
			this.byId("mapDirection").setBindingContext(oContext, "map");*/
		},

		onNavBack: function(event) {
			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();
			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				UIComponent.getRouterFor(this).navTo("Home");
			}
		},

		_onObjectMatched: function(oEvent) {
			var that = this;
			this.byId("mapDirection").setVisible(false);
			this.byId("mapMarker").setVisible(true);
			this.lat = oEvent.getParameter("arguments").lat;
			this.lng = oEvent.getParameter("arguments").lng;
			this.shop_lat = oEvent.getParameter("arguments").shop_lat;
			this.shop_lng = oEvent.getParameter("arguments").shop_lng;
			this.shop_name = oEvent.getParameter("arguments").shop_name;
			this.shop_adr = oEvent.getParameter("arguments").shop_adr;
			var places = [{
				shop_name: this.shop_name,
				shop_adr: this.shop_adr,
				shop_lat: this.shop_lat,
				shop_lng: this.shop_lng,
				current_lat: this.lat,
				current_llng: this.lng,
				start: "",
				end: ""
			}];

			var oModel = new sap.ui.model.json.JSONModel({
				places: places
			});
			this.getView().setModel(oModel, "map");
			var oContext = this.getView().getModel("map").getContext("/places/0/");
			this.byId("mapMarker").setBindingContext(oContext, "map");
			this.byId("pageMap").setBindingContext(oContext, "map");
			var oMap = this.byId("mapDirection");
			oMap.addEventDelegate({
				onAfterRendering: function() {
					that._setZoom();
				}
			});
			
			this._showhideHomeButton();
		},

		_setZoom: function() {
			var oMap = this.byId("mapDirection");
			var oDirections = oMap.getDirections();
			var options = {
				preserveViewport: true
			};
			oDirections.directions.setOptions(options);
		},

		_getLocation: function(oPos) {
			var oModel = this.getView().getModel("map");
			var oContext = oModel.getContext("/places/0/");
			oModel.setProperty("start", "My Location", oContext);
			oPos.lat = this.lat;
			oPos.lng = this.lng;
			return util.objToLatLng(oPos);
		},

		_updateLocation: function(sLocation) {
			var oModel = this.getView().getModel("map");
			var oContext = oModel.getContext("/places/0/");
			oModel.setProperty(oContext.getPath() + "start", sLocation, oContext);
		},

		onMyLocation: function(oEvent) {
			util.currentPosition()
				.then(this._getLocation.bind(this))
				.then(util.geocodePosition)
				.done(this._updateLocation.bind(this));
		}

	});

});