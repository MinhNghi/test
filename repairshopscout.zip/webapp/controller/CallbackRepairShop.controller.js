sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/core/routing/History",
	"sap/m/MessageBox",
	"jquery.sap.global",
	"atudoboilerplate/controller/BaseCRSController"
], function(UIComponent, History, MessageBox, jQuery, BaseCRSController) {
	"use strict";

	return BaseCRSController.extend("atudoboilerplate.controller.CallbackRepairShop", {
		onInit: function() {
			var curdate = new Date(),
				curyear = curdate.getFullYear(),
				curmonth = curdate.getMonth(),
				curday = curdate.getDate();
			this.byId("DP").setMinDate(new Date(curyear, curmonth, curday));
			this.byId("DP").setDateValue(new Date(curyear, curmonth, curday));

			//Set current time
			this.byId("TP").setDateValue(new Date(new Date().getTime()));
			this._iEvent = 0;

			// attach handlers for validation errors
			sap.ui.getCore().attachParseError(
				function(oEvent) {
					var oElement = oEvent.getParameter("element");
					if (oElement.setValueState) {
						oElement.setValueState("Error");
					}
				});

			sap.ui.getCore().attachValidationError(function(evt) {
				var control = evt.getParameter("element");
				if (control && control.setValueState) {
					control.setValueState("Error");
				}
			});
			sap.ui.getCore().attachValidationSuccess(function(evt) {
				var control = evt.getParameter("element");
				if (control && control.setValueState) {
					control.setValueState("None");
				}
			});

			this.getRouter().getRoute("CallbackRepairShop").attachPatternMatched(this._onObjectMatched, this);
		},

		onClose: function() {
			var oGeneralModel = sap.ui.getCore().getModel("general");
			var oGeneralData = oGeneralModel.getData();
			UIComponent.getRouterFor(this).navTo("RepairShopDetail", {
				lat: oGeneralData.lat,
				lng: oGeneralData.lng,
				Id: this.crsid,
				Id_user: oGeneralData.id_user,
				Distance: oGeneralData.distance,
				email: oGeneralData.email
			});
		},

		showCalendar: function() {
			this.byId("lblDate").setVisible(true);
			this.byId("lblTime").setVisible(true);
			this.byId("DP").setVisible(true);
			this.byId("TP").setVisible(true);
			this.byId("TP").setDateValue(new Date(new Date().getTime()));
			this.byId("DP").setDateValue(new Date());
		},

		hideCalendar: function() {
			this.byId("lblDate").setVisible(false);
			this.byId("lblTime").setVisible(false);
			this.byId("DP").setVisible(false);
			this.byId("TP").setVisible(false);
		},

		handleSelectionTime: function(event) {
			var oComboRate = this.getView().byId("cbTime");
			var sKey = oComboRate.getSelectedKey();
			if (sKey === "4") {
				this.showCalendar();
			} else {
				this.hideCalendar();
			}
		},

		//Handle to Send data
		handleSendRecall: function(oEvent) {
			var oBtnSubmit = this.byId("btnSubmit");
			oBtnSubmit.setEnabled(false);
			var sTelephone = this.getView().byId("txtTelephone").getValue();
			var oI18n = this.getView().getModel("i18n").getResourceBundle();
			var sMissingPhone = oI18n.getText("textMissingTel.callback");
			if (sTelephone === "" || sTelephone === undefined) {
				oBtnSubmit.setEnabled(true);
				this.getView().byId("txtTelephone").focus();
				MessageBox.error(sMissingPhone);
			} else {
				var that = this;
				var dDate = new Date();
				var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "yyyy-MM-dd'T'HH:mm:ss"
				});
				var dateDisplayFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "dd-MM-yyyy"
				});
				var timeDisplayFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "HH:mm"
				});
				var tTimeRecall,
					dRecallDate,
					sEvent,
					date_display,
					time_display,
					tAppoint;
				var oView = this.getView();
				var sPhone = oView.byId("txtTelephone").getValue();
				var sVorName = oView.byId("txtVorname").getValue();
				var sName = oView.byId("txtName").getValue();
				var oComboRate = this.getView().byId("cbTime");
				var sKey = oComboRate.getSelectedKey();
				switch (sKey) {
					case "1":
						tTimeRecall = dDate.getTime();
						dRecallDate = dateFormat.format(new Date(tTimeRecall));
						date_display = dateDisplayFormat.format(new Date(tTimeRecall));
						time_display = timeDisplayFormat.format(new Date(tTimeRecall));
						sEvent = "Phone: " + sPhone + ", Name: " + sVorName + " " + sName + ", Date: now.";
						break;
					case "2":
						tTimeRecall = dDate.getTime() + 10 * 60 * 1000;
						dRecallDate = dateFormat.format(new Date(tTimeRecall));
						date_display = dateDisplayFormat.format(new Date(tTimeRecall));
						time_display = timeDisplayFormat.format(new Date(tTimeRecall));
						sEvent = "Phone:\"" + sPhone + "\", Name:\"" + sVorName + " " + sName + "\", Date:\"" + dRecallDate + "\"";
						break;
					case "3":
						tTimeRecall = dDate.getTime() + 60 * 60 * 1000;
						dRecallDate = dateFormat.format(new Date(tTimeRecall));
						date_display = dateDisplayFormat.format(new Date(tTimeRecall));
						time_display = timeDisplayFormat.format(new Date(tTimeRecall));
						sEvent = "Phone:\"" + sPhone + "\", Name:\"" + sVorName + " " + sName + "\", Date:\"" + dRecallDate + "\"";
						break;
					case "4":
						tAppoint = oView.byId("TP").getValue();
						var dAppoint = oView.byId("DP").getValue();
						dRecallDate = dAppoint + tAppoint;
						date_display = dateDisplayFormat.format(oView.byId("DP").getDateValue());
						time_display = tAppoint;
						sEvent = "Phone:\"" + sPhone + "\", Name:\"" + sVorName + " " + sName + "\", Date:\"" + dRecallDate + ":00\"";
						break;
				}

				// Create a CRS Log with type r
				var oProperties = {
					Type: "r",
					Status: "n",
					Id_User: that.UserId,
					CRSId: that.crsid,
					Event: sEvent
				};
				this.createCRSLog(oProperties);
			}
		},

		//Handle Date changed
		handleDateChange: function(oEvent) {
			var oDP = oEvent.getSource();
			var bValid = oEvent.getParameter("valid");
			this._iEvent++;

			if (bValid) {
				oDP.setValueState("None");
			} else {
				oDP.setValueState("Error");
			}
		},

		//Handle Time changed
		handleTimeChange: function(oEvent) {
			var oTP = oEvent.getSource();
			var bValid = oEvent.getParameter("valid");
			this._iEvent++;
			if (bValid) {
				oTP.setValueState("None");
			} else {
				oTP.setValueState("Error");
			}

		},

		_onObjectMatched: function(oEvent) {
			this.UserId = oEvent.getParameter("arguments").UserId;
			this.crsid = oEvent.getParameter("arguments").CRSId;
			this._showhideHomeButton();
			this.hideCalendar();
			var oBtnSubmit = this.byId("btnSubmit");
			if (oBtnSubmit.getEnabled() === false) {
				oBtnSubmit.setEnabled(true);
			}
			
			//Add dummy box
			if (sap.ui.Device.system.phone && sap.ui.Device.browser.mobile) {
				this._addDummyBox();
			}
		},
		
		_addDummyBox: function() {
			var oBoxDummy = this.byId("boxDummy");
			var oVornameText = this.byId("txtVorname");
			var oNameText = this.byId("txtName");
			var oTelephoneText = this.byId("txtTelephone");
			var oTime = this.byId("cbTime");
			var oDP = this.byId("DP");
			var oTP = this.byId("TP");

			oVornameText.addEventDelegate({
				onfocusin: function() {
					oBoxDummy.setVisible(true);
				},
				onfocusout: function() {
					oBoxDummy.setVisible(false);
				}
			});

			oNameText.addEventDelegate({
				onfocusin: function() {
					oBoxDummy.setVisible(true);
				},
				onfocusout: function() {
					oBoxDummy.setVisible(false);
				}
			});

			oTelephoneText.addEventDelegate({
				onfocusin: function() {
					oBoxDummy.setVisible(true);
				},
				onfocusout: function() {
					oBoxDummy.setVisible(false);
				}
			});
			
			oTime.addEventDelegate({
				onfocusin: function() {
					oBoxDummy.setVisible(true);
				},
				onfocusout: function() {
					oBoxDummy.setVisible(false);
				}
			});
			
			oDP.addEventDelegate({
				onfocusin: function() {
					oBoxDummy.setVisible(true);
				},
				onfocusout: function() {
					oBoxDummy.setVisible(false);
				}
			});
			
			oTP.addEventDelegate({
				onfocusin: function() {
					oBoxDummy.setVisible(true);
				},
				onfocusout: function() {
					oBoxDummy.setVisible(false);
				}
			});
		}

	});

});