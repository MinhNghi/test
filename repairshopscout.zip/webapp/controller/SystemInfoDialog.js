sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], function(Controller, JSONModel) {
	"use strict";

	return Controller.extend("atudoboilerplate.controller.SystemInfoDialog", {

		_getDialog: function() {
			if (!this._oDialog) {
				this._oDialog = sap.ui.xmlfragment("atudoboilerplate.view.SystemInfoDialog", this);
			}
			return this._oDialog;
		},

		open: function(oView) {
			jQuery.sap.require("jquery.sap.storage");
			var oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.local);
			var bDebug = oStorage.get("debugFlag");
			var iCounter = 0;
			if (bDebug === true) {
				iCounter = oStorage.get("counterCall");
			}
			var oDialog = this._getDialog();
			var oGeneralData = sap.ui.getCore().getModel("general").getData();
			var sToken;
			if (oGeneralData.email.includes("@bauerkemper") || oGeneralData.email.includes("@eifrig") || oGeneralData.email.includes(
					"@b2invent") || oGeneralData.email.includes("@meyle") || oGeneralData.email === "me@example.com") {
				sToken = oGeneralData.token;
			} else {
				sToken = "n/a";
			}
			var oViewModel = new JSONModel({
				email: oGeneralData.email,
				token: sToken,
				userid: oGeneralData.id_user,
				username: oGeneralData.username,
				lng: oGeneralData.lng,
				lat: oGeneralData.lat,
				identifyId: oGeneralData.identifyId,
				counter: iCounter
			});
			
			oView.addDependent(oDialog);
			oDialog.setModel(oViewModel, "userinfo");
			oDialog.bindElement({
				path: "/",
				model: "userinfo"
			});
			
			if (bDebug === true) {
				var oBoxCounter = sap.ui.getCore().byId("boxCounter");
				oBoxCounter.setVisible(true);
			}
			
			oDialog.open();

			setTimeout(function() {
				oDialog.close();
			}, 30000);
		},

		onOk: function() {
			var oDialog = this._getDialog();
			oDialog.close();
		}
	});

});