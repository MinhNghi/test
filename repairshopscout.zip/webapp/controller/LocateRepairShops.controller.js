sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Sorter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox",
	"atudoboilerplate/model/formatter",
	"google.maps",
	"atudoboilerplate/controller/BaseCRSController"
], function(UIComponent, JSONModel, Sorter, Filter, FilterOperator, MessageBox, formatter, googlemaps, BaseCRSController) {
	"use strict";

	return BaseCRSController.extend("atudoboilerplate.controller.LocateRepairShops", {
		formatter: formatter,
		onInit: function() {
			var oView = this.getView();
			var oViewModel = new JSONModel({
				viewFavorites: false,
				sort: ""
			});
			oView.setModel(oViewModel, "settings");
			oView.bindElement({
				path: "/",
				model: "settings"
			});
			UIComponent.getRouterFor(this).getRoute("LocateRepairShops").attachPatternMatched(this.onObjectMatched, this);
		},

		// Start - For events of the User GUI onXXX
		// Event of the GUI when click on item list to go detail
		onDetailPress: function(event) {
			var oItem = event.getSource();
			var oContext = oItem.getBindingContext("rs");
			var oModel = oContext.getModel();
			oModel.oMetadata.sUser = this.Id_user;

			// Navigate to CRS Detail page
			this.CRSId = oItem.getBindingContext("rs").getProperty("CRSId");
			this.distance = oItem.getBindingContext("rs").getProperty("Distance");
			this.onNavDetail();
		},

		// Event of the GUI when click setting button
		onSettingPress: function(event) {
			UIComponent.getRouterFor(this).navTo("Settings", {
				email: this.email,
				lat: this.lat,
				lng: this.lng
			});
		},
		// End - For events of the User GUI onXXX

		// Start - For events from or to the system or as a reaction of a “onXXX” event
		// Reaction of event onInit()
		onObjectMatched: function(oEvent) {
			// Set all parameters of query to variables to use in next pages.
			var args = oEvent.getParameter("arguments");
			this.email = args.email;
			this.lng = args.lng;
			this.lat = args.lat;
			this.token = args.token;
			this.email = args.email;
			this.Id_user = args.Id_user;
			this.identifyId = args.atuid;
			if (this.identifyId === undefined || this.identifyId === '') {
				this.identifyId = this.email;
			}
			this._oSorter = null;

			// For testing user Luan at VietNam, will be removed after test phase.
			if (this.email === "luan.thuc.trong.nguyen@b2invent.com") {
				this.lng = 9.993682;
				this.lat = 53.551086;
			}

			// Set show/hide Home button
			this._showhideHomeButton();

			var that = this;
			var aUserFilter = [];
			aUserFilter.push(new Filter("Service_Provider", FilterOperator.EQ, "Atudo"));
			aUserFilter.push(new Filter("User_Identify", FilterOperator.EQ, this.identifyId));
			aUserFilter.push(new Filter("User_Token", FilterOperator.EQ, this.token));
			aUserFilter.push(new Filter("Pseudonym", FilterOperator.EQ, this.email));
			// Get ID_User from user credentials
			var oComponent = this.getOwnerComponent();
			var oModel = oComponent.getModel("rs");
			oModel.read("/CRS_UserSet", {
				async: false,
				filters: aUserFilter,
				success: function(oUserData) {
					that.Id_user = oUserData.results[0].ID_User;

					var oGeneralModel = new sap.ui.model.json.JSONModel();
					oGeneralModel.setData({
						email: that.email,
						lat: that.lat,
						lng: that.lng,
						identifyId: that.identifyId,
						id_user: that.Id_user,
						token: that.token,
						username: oUserData.results[0].Pseudonym,
						distance: ""
					});
					sap.ui.getCore().setModel(oGeneralModel, "general");

					jQuery.sap.require("jquery.sap.storage");
					var oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.local);

					//Splash screen
					var bSplashScreens = oStorage.get("bSplashScreens");
					if (bSplashScreens === null || bSplashScreens === false) {
						var dCreateTime = new Date(oUserData.results["0"].Create_Time);
						var dNow = new Date();
						var nMSecDiff = 86400 * 1000; // a day
						if (dNow - dCreateTime < nMSecDiff) {
							oStorage.put("bSplashScreens", true);
							UIComponent.getRouterFor(that).navTo("SplashScreen", {
								lat: that.lat,
								lng: that.lng
							});
						}
					}

					that._displayPage();

					// Test call CRSFindSet
					/* EB 28.09.17 Not longer needed
					var bDebug = oStorage.get("debugFlag");
					var iCounter = oStorage.get("counterCall");
					if (bDebug === true) {
						setInterval(function() {
							iCounter = iCounter + 1;
							oStorage.put("counterCall", iCounter);
							that._callCRSFindSet();
						}, 300000);
					} else {
						*/
					/*setInterval(function() {
												var oMapModel = that.getView().byId("mapMarker").getModel();
												var oData = oMapModel.getData();
												var oMarker;
												for (var i = 1; i < oData.markers.length; i++) {
													var sId = oData.markers[i].id;
													oMarker = that.byId(sId);
													var sContent = oMarker.infoWindow.getContent();
												}
											}, 10000);*/
					/*
										}
										*/
				},
				error: function() {
					MessageBox.error("Failed to get login, wrong email or token !");
				}
			});
		},
		// End - For events from or to the system or as a reaction of a “onXXX” event

		// Start - Section for all private functions.
		// Private display page
		_displayPage: function() {
			//Disable button locate repair shop
			this.getView().byId("btnList").setEnabled(false);

			// Add data to list and appointment
			this._displayListItems();
			this._displayAppointmentNotif();
			this._setIcon();
		},

		// Private display data in car repair shop list
		_displayListItems: function() {
			var that = this;
			var oView = this.getView();
			var filters = [];
			filters.push(new Filter("Longitude", FilterOperator.EQ, this.lng));
			filters.push(new Filter("Latitude", FilterOperator.EQ, this.lat));
			filters.push(new Filter("UserId", FilterOperator.EQ, this.Id_user));
			jQuery.sap.require("sap.ui.core.format.NumberFormat");
			var oModel = this.getView().getModel("rs");
			var oList = oView.byId("repairShopList");
			oList.setModel(oModel);
			oList.getModel().setSizeLimit(30);
			var oBinding = oList.getBinding("items");
			oBinding.filter(filters);

			oList.addEventDelegate({
				onAfterRendering: function() {
					that._setIcon();
					that._setMap(that);
				}
			}, this);

			var oSettingsModel = sap.ui.getCore().getModel("settings");
			if (oSettingsModel !== undefined && oSettingsModel !== null) {
				var oSettingsData = oSettingsModel.getData();
				//Filtering
				if (oSettingsData.Type !== "") {
					filters.push(new Filter("Type", FilterOperator.EQ, oSettingsData.Type));
					oBinding.filter(filters);
				}

				// Sorting
				if (oSettingsData.Path !== "" && oSettingsData.Descending !== "") {
					this._oSorter = new Sorter({
						path: oSettingsData.Path,
						descending: oSettingsData.Descending
					});
					oBinding.sort(this._oSorter);
				}

				//Update data on list
				if (oSettingsData.Type !== "" || oSettingsData.Path !== "" || oSettingsData.Descending !== "") {
					oBinding.getModel().updateBindings();
				}
			}

			//this._setMap(this);
			var oMap = oView.byId("mapMarker");
			var oMapModel = oMap.getModel();
			if (oMapModel !== undefined) {
				this._resetMarker(oMap);
			}

		},

		// Private display appointment notification
		_displayAppointmentNotif: function(event) {
			var that = this;
			var oModel = this.getView().getModel("rs");
			var oList = that.getView().byId("notificationList");
			var oI18n = this.getView().getModel("i18n").getResourceBundle();
			var list = [];
			var oJsonModel = new sap.ui.model.json.JSONModel({
				appointment: list
			});
			var oAppointFilter = [];
			oAppointFilter.push(new Filter("Id_User", FilterOperator.EQ, this.Id_user));
			oAppointFilter.push(new Filter("CRSId", FilterOperator.NE, "0"));
			oAppointFilter.push(new Filter("Status", FilterOperator.EQ, "o"));

			oModel.read("/CRS_AppointmentSet", {
				async: false,
				filters: oAppointFilter,
				success: function(oAppointData) {
					var i,
						j,
						count = 0,
						sDescription,
						oDate;
					var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
						pattern: "dd.MM.yyyy"
					});
					var dCurrentDate = new Date();
					var currentDate = dCurrentDate.getTime();
					for (i = 0; i < oAppointData.results.length; i++) {
						if (oAppointData.results[i].Type === "n" || oAppointData.results[i].Type === "a") {
							var contactDate = oAppointData.results[i].Next_Contact.getTime();
							if (contactDate > currentDate) {
								count += 1;
							}
						}
					}
					if (count === 1) {
						for (j = 0; j < oAppointData.results.length; j++) {
							oList.setVisible(true);
							if (oAppointData.results[j].Next_Contact.getTime() > currentDate &&
								(oAppointData.results[j].Type === "n" || oAppointData.results[j].Type === "a")) {
								oDate = oDateFormat.format(oAppointData.results[j].Next_Contact);
								sDescription = oI18n.getText("textOneAppoint.locate") + oDate + ".";
								list.push({
									Event: oAppointData.results[j].Event,
									DateTime: oDate,
									CRSId: "",
									Description: sDescription,
									Name: "",
									Address: "",
									Telephone: ""
								});
							}
						}
						oList.setModel(oJsonModel);
						oList.setVisible(true);
					} else if (count > 1) {
						oList.setVisible(true);
						sDescription = oI18n.getText("textMoreAppoint.locate");
						list.push({
							Description: sDescription
						});
						oList.setModel(oJsonModel);
						oList.setVisible(true);
					} else if (count < 1) {
						oList.setVisible(false);
					}
				},
				error: function(oError) {
					oList.setVisible(false);
				}
			});
		},

		// Private display markers with coordinates on map
		_setMap: function(obj) {
			var that = this;
			var aMarkerId = [];
			var markers = [];
			var oMarker = {};
			var oMap = obj.getView().byId("mapMarker");
			var sViewId = obj.getView().getId();
			var sId = sViewId + "--marker-" + oMap.getId() + "-" + "0";

			markers.push({
				id: sId,
				lat: that.lat,
				lng: that.lng,
				shopInfo: "",
				shopLat: that.lat,
				shopLng: that.lng
			});

			aMarkerId.push({
				id: sId,
				shopInfo: ""
			});

			var oList = this.byId("repairShopList");
			oList.getBinding("items").getModel().updateBindings();
			var oContext = oList.getBinding("items").getCurrentContexts();
			var i, j, k;
			if (oContext.length > 0) {
				for (i = 0; i < 3; i++) {
					var sPath = oContext[i].getPath();
					var oData = oList.getModel().getProperty(sPath);
					var sTarget = that._getUrlDetail(oData);
					var sImgScr,
						sInfoContent;
					if (oData.Favorite === true) {
						sImgScr = '<img width="15px" height="15px" id="imgShadow" src="img/NoText/Orange/ic_Favorit_24p_Orange.svg">';
						sInfoContent = sImgScr + '<b><a href="' + sTarget + '">' + oData.Name + '</a></b>';
					} else {
						sInfoContent = '<b><a href="' + sTarget + '">' + oData.Name + '</a></b>';
					}
					var iPos = i + 1;
					sId = sViewId + "--marker-" + oMap.getId() + "-" + iPos;

					markers.push({
						id: sId,
						lat: that.lat,
						lng: that.lng,
						shopInfo: sInfoContent,
						shopLat: oData.Latitude,
						shopLng: oData.Longitude
					});

					aMarkerId.push({
						id: sId,
						shopInfo: sInfoContent
					});
				}

				var oJsonModel = new sap.ui.model.json.JSONModel({
					markers: markers
				});
				oMap.setModel(oJsonModel);
				var mapOptions = {
					draggable: false,
					scrollwheel: false,
					disableDoubleClickZoom: true,
					zoomControl: false
				};
				oMap.map.setOptions(mapOptions);

				var oPos;
				var aLatLng = [];
				for (j = 0; j < aMarkerId.length; j++) {
					oMarker = sap.ui.getCore().byId(aMarkerId[j].id);
					if (oMarker.aListeners.length === 0) {
						oMarker.setMarker();
					}
					if (oMarker.aListeners.length !== 0) {
						var oMarkerOptions = oMarker.getOptions();
						oMarkerOptions.optimized = false;
						oMarker.marker.setOptions(oMarkerOptions);
						if (j === 0) {
							var image = {
								url: "img/position_icon.svg",
								size: new googlemaps.Size(60, 60),
								origin: new googlemaps.Point(0, 0),
								anchor: new googlemaps.Point(0, 32),
								scaledSize: new googlemaps.Size(25, 25)
							};
							oMarker.setIcon(image);
							oMarker.aListeners.forEach(function(t) {
								t.remove();
							});

							oPos = oMarker.marker.getPosition();
							aLatLng.push(oPos);
						} else {
							oPos = oMarker.marker.getPosition();
							aLatLng.push(oPos);
							oMarker.infoWindow.setContent(aMarkerId[j].shopInfo);
							oMarker.infoWindowOpen();
							oMarker.setVisible(false);
						}
					}
				}

				// Set auto zoom and fit marker on Map.
				var latlngbounds = new googlemaps.LatLngBounds();
				for (k = 0; k < aLatLng.length; k++) {
					latlngbounds.extend(aLatLng[k]);
				}
				oMap.map.fitBounds(latlngbounds);
				oMap.map.panToBounds(latlngbounds);
			}
		},

		_callCRSFindSet: function() {
			var oModel = this.getView().getModel("rs");
			var aFilter = [];
			var oProperties = {
				Type: "",
				Id_User: this.Id_user
			};
			aFilter.push(new Filter("Longitude", FilterOperator.EQ, this.lng));
			aFilter.push(new Filter("Latitude", FilterOperator.EQ, this.lat));
			aFilter.push(new Filter("UserId", FilterOperator.EQ, this.Id_user));
			oModel.read("/CRS_FindSet", {
				async: false,
				filters: aFilter,
				success: function(oShopData, response) {
					if (oShopData.results.length > 0) {
						oProperties.Type = "g";
						oModel.createEntry("/CRS_LogSet", {
							properties: oProperties
						});
						oModel.submitChanges();
					} else {
						oProperties.Type = "x";
						oModel.createEntry("/CRS_LogSet", {
							properties: oProperties
						});
						oModel.submitChanges();
					}
				},
				error: function(oError) {
					oProperties.Type = "x";
					oModel.createEntry("/CRS_LogSet", {
						properties: oProperties
					});
					oModel.submitChanges();
				}
			});
		},

		_resetMarker: function(oMap) {
				var oMarker;
				var oMapData = oMap.getModel().getData();
				for (var i = 1; i < oMapData.markers.length; i++) {
					oMarker = this.byId(oMapData.markers[i].id);
					oMarker.infoWindow.setContent(oMapData.markers[i].shopInfo);
					oMarker.infoWindowOpen();
				}
			}
			// End - Section for all private functions.
	});
});