sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], function(Controller, JSONModel) {
	"use strict";

	return Controller.extend("atudoboilerplate.controller.LoginDialog", {

    	_getDialog: function () {
            // create dialog lazily
            if (!this._oDialog) {
                // create dialog via fragment factory
                this._oDialog = sap.ui.xmlfragment("atudoboilerplate.view.LoginDialog", this);
            }
            return this._oDialog;
        },

        open: function (oView) {

            var oDialog = this._getDialog();

            // connect dialog to view (models, lifecycle)
            oView.addDependent(oDialog);

			var oViewModel = new JSONModel({
				atuid:"",
				email: "",
				password: ""
			});
			oDialog.setModel(oViewModel, "cred");
			oDialog.bindElement({
				path: "/",
				model: "cred"
			});

            // open dialog
            oDialog.open();
        },

        onLogin: function (oEvent) {
        	var oDialog = this._getDialog();
    		oDialog.close();
        }
    });

});