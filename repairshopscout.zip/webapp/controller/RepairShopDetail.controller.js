sap.ui.define([
	"atudoboilerplate/controller/MyController",
	"sap/ui/core/UIComponent",
	"sap/ui/core/routing/History",
	"sap/ui/model/json/JSONModel",
	"atudoboilerplate/model/formatter",
	"openui5/googlemaps/MapUtils",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox",
	"atudoboilerplate/controller/BaseCRSController"
], function(MyController, UIComponent, History, JSONModel, formatter, util, Filter, FilterOperator, MessageBox, BaseCRSController) {
	"use strict";

	return BaseCRSController.extend("atudoboilerplate.controller.RepairShopDetail", {
		formatter: formatter,
		onInit: function() {
			var iOriginalBusyDelay,
				oViewModel = new JSONModel({
					busy: true,
					delay: 0
				});

			this.getRouter().getRoute("RepairShopDetail").attachPatternMatched(this.onObjectMatched, this);

			// Store original busy indicator delay, so it can be restored later on
			iOriginalBusyDelay = this.getView().getBusyIndicatorDelay();
			this.setModel(oViewModel, "objectView");
			this.getOwnerComponent().getModel("rs").metadataLoaded().then(function() {
				// Restore original busy indicator delay for the object view
				oViewModel.setProperty("/delay", iOriginalBusyDelay);
			});
		},

		// Start - For events of the User GUI onXXX
		// Event of the GUI when click on Back button
		onBackPress: function(event) {
			this.onSwipe = true;
			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();
			if (sPreviousHash === undefined) {
				window.history.go(-1);
				return;
			}
			if (sPreviousHash.includes("LocateRepairShops") ||
				sPreviousHash.includes("Karte") ||
				sPreviousHash.includes("RepairShopAppointment") ||
				sPreviousHash.includes("FavoriteRepairShops")) {
				window.history.go(-1);
			} else {
				this.onLocatePress();
			}
		},

		// Event of the GUI when click on star button to like the shop
		onLikePress: function(event) {
			this._updateFavorite(event);
		},

		// Event of the GUI when user click button to expand the review list
		onExpandReviewList: function(event) {
			var oBtnExpand = this.byId("btnExpand");
			var oBtnCollapse = this.byId("btnCollapse");
			var oReviewList = this.byId("reviewList");
			var oReviewExpandList = this.byId("reviewExpandList");
			oBtnExpand.setVisible(false);
			oReviewList.setVisible(false);
			oBtnCollapse.setVisible(true);
			oReviewExpandList.setVisible(true);
		},

		// Event of the GUI when user click button to collapse the review list
		onCollapseReviewList: function(event) {
			var oBtnCollapse = this.byId("btnCollapse");
			var oBtnExpand = this.byId("btnExpand");
			var oReviewList = this.byId("reviewList");
			var oReviewExpandList = this.byId("reviewExpandList");
			oBtnExpand.setVisible(true);
			oReviewList.setVisible(true);
			oBtnCollapse.setVisible(false);
			oReviewExpandList.setVisible(false);
		},

		// Event of the GUI when user click button to move review area
		onReviewPress: function(event) {
			UIComponent.getRouterFor(this).navTo("ReviewRepairShop", {
				CRSId: this.crsid,
				UserId: this.id_user
			});
		},

		// Event of the GUI when user click button to go to the map page
		onMapPress: function(event) {
			var oSource = event.getSource();
			var oBindingContext = oSource.getBindingContext("rs");
			var sShop_lat = oBindingContext.getProperty("Latitude");
			var sShop_lng = oBindingContext.getProperty("Longitude");
			var sShop_name = oBindingContext.getProperty("Name");
			var sCity = oBindingContext.getProperty("City");
			var sStreet = oBindingContext.getProperty("Street");
			var sShop_adr = sCity + " " + sStreet;
			/*jQuery.sap.require("jquery.sap.storage");
			var oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.local);
			var bDebug = oStorage.get("debugFlag");
			if (bDebug === true) {
				UIComponent.getRouterFor(this).navTo("RepairShopMap", {
					lat: this.lat,
					lng: this.lng,
					shop_lat: sShop_lat,
					shop_lng: sShop_lng,
					shop_adr: sShop_adr,
					shop_name: sShop_name
				});
			} else {
				var sDestination = "atudo://service:navigation/destination:" + sShop_lat + "," + sShop_lng;
				sap.m.URLHelper.redirect(sDestination);
			}*/

			UIComponent.getRouterFor(this).navTo("RepairShopMap", {
				lat: this.lat,
				lng: this.lng,
				shop_lat: sShop_lat,
				shop_lng: sShop_lng,
				shop_adr: sShop_adr,
				shop_name: sShop_name
			});
		},

		// Event of the GUI when user click button to go to page call repair shop
		onCallShopPress: function(event) {
			UIComponent.getRouterFor(this).navTo("CallRepairShop", {
				lat: this.lat,
				lng: this.lng,
				CRSId: this.crsid,
				UserId: this.id_user
			});
		},

		// Event of the GUI when user click button to go to page edit repair shop
		onEditPress: function(event) {
			var oItem = event.getSource();
			this.getRouter().navTo("EditRepairShop", {
				lat: this.lat,
				lng: this.lng,
				shopPath: oItem.getBindingContext("rs").getPath().substr(1)
			});
		},
		// End - For events of the User GUI onXXX

		// Start - For events from or to the system or as a reaction of a “onXXX” event
		// Reaction of event onInit()
		onObjectMatched: function(oEvent) {
			var oGeneralModel = sap.ui.getCore().getModel("general");
			this.lat = oEvent.getParameter("arguments").lat;
			this.lng = oEvent.getParameter("arguments").lng;
			this.email = oEvent.getParameter("arguments").email;
			this.Id_user = oEvent.getParameter("arguments").Id_user;
			this.id_user = oEvent.getParameter("arguments").Id_user;
			this.crsid = oEvent.getParameter("arguments").Id;
			var sDistance = oEvent.getParameter("arguments").Distance;
			this.distance = formatter.distance(sDistance);
			this.expanded = false;
			this._showhideHomeButton();
			if (oGeneralModel === undefined) {
				oGeneralModel = new sap.ui.model.json.JSONModel();
				oGeneralModel.setData({
					email: this.email,
					lat: this.lat,
					lng: this.lng,
					id_user: this.Id_user,
					token: this.token,
					username: "",
					distance: sDistance
				});
				sap.ui.getCore().setModel(oGeneralModel, "general");

			} else {
				var oGeneralData = oGeneralModel.getData();
				oGeneralData.distance = sDistance;
				sap.ui.getCore().setModel(oGeneralModel, "general");
			}
			var sObjectId = oEvent.getParameter("arguments").Id;
			this.getModel("rs").metadataLoaded().then(function() {
				var sObjectPath = this.getModel("rs").createKey("CRS_DataSet", {
					CRSId: sObjectId,
					Version: 0
				});
				this._bindView(sObjectPath);
			}.bind(this));

			// Set event focust on Review text.
			var oSubjectText = this.byId("txtSubject");
			var oReviewText = this.byId("txtComment");
			var oBoxDummy = this.byId("boxDummy");
			if (oReviewText !== undefined) {
				if (sap.ui.Device.system.phone && sap.ui.Device.browser.mobile) {
					oReviewText.addEventDelegate({
						onfocusin: function() {
							oBoxDummy.setVisible(true);
						},
						onfocusout: function() {
							oBoxDummy.setVisible(false);
						}
					});
					oSubjectText.addEventDelegate({
						onfocusin: function() {
							oBoxDummy.setVisible(true);
						},
						onfocusout: function() {
							oBoxDummy.setVisible(false);
						}
					});
				}
			}

			// Setting URL back.
			var that = this;
			window.addEventListener("hashchange", function(e) {
				var oHistory = History.getInstance();
				var oDirection = oHistory._oHashChanger.getMetadata();
				var iCurrPos = oHistory.iHistoryPosition;
				var sPreviousHash = oHistory.getPreviousHash();
				var sNextHash = oHistory.aHistory[iCurrPos];
				if (oHistory._sCurrentDirection === "Backwards") {
					if (sPreviousHash === undefined) {
						return;
					}
					if (sPreviousHash.includes("RepairShopDetail")) {
						if (sNextHash.includes("LocateRepairShops") ||
							sNextHash.includes("FavoriteRepairShops") ||
							sNextHash.includes("Karte") ||
							sNextHash.includes("RepairShopAppointment")) {
							return;
						} else {
							that.onLocatePress();
						}
					} else {
						var sCurrentHash = oHistory.aHistory[iCurrPos + 1];
						if (sCurrentHash.includes("RepairShopDetail")) {
							if (sNextHash.includes("LocateRepairShops") ||
								sNextHash.includes("FavoriteRepairShops") ||
								sNextHash.includes("Karte") ||
								sNextHash.includes("RepairShopAppointment")) {
								return;
							} else {
								that.onLocatePress();
							}
						} else if (sCurrentHash.includes("LocateRepairShops")) {
							that.onHomePress();
						}
					}
				}
			});
		},
		// End - For events from or to the system or as a reaction of a “onXXX” event

		// Start - Section for all private functions.
		// Private bind data to view of page
		_bindView: function(sObjectPath) {
			this.getView().byId("txtDistance").setText(this.distance);
			var oViewModel = this.getModel("objectView"),
				oDataModel = this.getModel("rs");
			var that = this;
			this.getView().bindElement({
				path: "rs>/" + sObjectPath,
				events: {
					change: this._onBindingChange.bind(this),
					dataRequested: function() {
						oDataModel.metadataLoaded().then(function() {
							oViewModel.setProperty("/busy", true);
						});
					},
					dataReceived: function() {
						oViewModel.setProperty("/busy", false);
					}
				}
			});

			this._setBrandsAndDescription(sObjectPath);

			// Read data Car Repair Shop Favorite
			var oModel = this.getModel("rs");
			var sFavoritenPath = "/CRS_FavoritenSet(CRSID=" + this.crsid + ",id_User=" + this.id_user + ")";
			oModel.read(sFavoritenPath, {
				success: function(oData) {
					that._setLikeDislike(oData.Type_Favo);
				},
				error: function() {
					that._setLikeDislike("");
				}
			});

			// Review list
			this.getView().byId("btnExpand").setVisible(true);
			this.getView().byId("btnCollapse").setVisible(false);
			var hidden = [];
			var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
				pattern: "dd/MM/yyyy HH:mm"
			});
			var oReviewList = this.getView().byId("reviewList");
			var oReviewExpandList = this.getView().byId("reviewExpandList");
			var aFilter = [];
			var oFilter1 = new Filter("CRSId", FilterOperator.EQ, this.crsid);
			var oFilter2 = new Filter("Id_User", FilterOperator.EQ, this.id_user);
			var oFilter3 = new Filter("Status", FilterOperator.EQ, "o");
			var oFilter = new Filter({
				filters: [
					oFilter1,
					oFilter2,
					oFilter3
				],
				and: true
			});

			aFilter.push(oFilter);

			oModel.read("/CRS_ReviewSet", {
				filters: aFilter,
				success: function(oData, response) {
					var aReviewList = [];
					for (var i = 0; i < oData.results.length; i++) {
						//	var oDate = oDateFormat.format(oData.results[i].Create_Time);
						aReviewList.push({
							Id_Review: oData.results[i].Id_Review,
							CRSId: oData.results[i].CRSId,
							Id_User: oData.results[i].Id_User,
							Runing_Nr: oData.results[i].Runing_Nr,
							Reply_Nr: oData.results[i].Reply_Nr,
							Subject: oData.results[i].Subject,
							Review_Text: oData.results[i].Review_Text,
							Review_Value: parseFloat(oData.results[i].Review_Value),
							Quotation_Text: oData.results[i].Quotation_Text,
							Status: oData.results[i].Status,
							Pseudonym: oData.results[i].Pseudonym,
							Create_Time: oDateFormat.format(oData.results[i].Create_Time),
							Update: "FALSE"
						});

						if (!oData.results[i].Quotation_Text) {
							hidden.push({
								pos: i
							});
						}
					}

					if (aReviewList === undefined) {
						aReviewList.push({
							Id_Review: "0",
							CRSId: "",
							Id_User: "",
							Runing_Nr: "0",
							Reply_Nr: "0",
							Subject: "",
							Review_Text: "",
							Review_Value: 0,
							Quotation_Text: "",
							Status: "",
							Pseudonym: "",
							Create_Time: "",
							Update: "FALSE"
						});
					}

					var oReviewExpandModel = new JSONModel({
						review: aReviewList
					});
					var oReviewCollapseModel = new JSONModel({
						review: aReviewList
					});
					//that.setModel(oReviewExpandModel, "review");
					oReviewCollapseModel.iSizeLimit = 1;
					oReviewList.setModel(oReviewCollapseModel);
					oReviewList.setVisible(true);
					// Expand Review List	
					oReviewExpandList.setModel(oReviewExpandModel);
					oReviewExpandList.setVisible(false);
				}
			});
		},

		// Private update binding data when changes
		_onBindingChange: function() {
			var oViewModel = this.getModel("objectView");
			oViewModel.setProperty("/busy", false);

			// Set type icon free or contract.
			this._setIconType();
		},

		// Private update favorite field to backend
		_updateFavorite: function() {
			var that = this;
			var oModel = this.getView().getModel("rs");
			var sPath = "/CRS_FavoritenSet(CRSID=" + this.crsid + ",id_User=" + this.id_user + ")";
			oModel.read(sPath, {
				success: function(oData) {
					switch (oData.Type_Favo) {
						case "F":
							oData.Type_Favo = "";
							break;
						case "A":
							oData.Type_Favo = "F";
							break;
						case "":
							oData.Type_Favo = "F";
							break;
					}
					// Update data to backend.
					oModel.update(sPath, oData, null, {
						success: function() {
							oModel.refresh(true);
						},
						error: function() {
							jQuery.sap.require("sap.m.MessageBox");
							sap.m.MessageBox.alert("Fehler beim Update!");
						}
					});
					that._setLikeDislike(oData.Type_Favo);
				},
				error: function() {
					// Create an entry favorite before.
					var oDataCreate = {
						CRSID: that.crsid,
						id_User: that.id_user,
						Type_Favo: "F"
					};
					oModel.create("/CRS_FavoritenSet", oDataCreate, null, {
						success: function() {
							oModel.refresh();
						}
					});
					that._setLikeDislike(oDataCreate.Type_Favo);
				}
			});
		},

		// Private set image of icon type to frontend
		_setIconType: function() {
			var oModel = this.getView().getModel("rs");
			var sPath = "/CRS_DataSet(CRSId=" + this.crsid + "m,Version=0m)";
			var oData = oModel.getProperty(sPath);
			// Set Type icon on list
			var oImgType = this.getView().byId("imgType");
			if (typeof oImgType !== "undefined") {
				switch (oData.Type) {
					case "contract":
						oImgType.setSrc("img/Vertragswerkstatt.svg");
						break;
					case "free":
						oImgType.setSrc("img/Freie_Werkstatt.svg");
						break;
					default:
						oImgType.setSrc("img/Freie_Werkstatt.svg");
						break;
				}
			}
		},

		// Create description for CRS
		_setBrandsAndDescription: function(sObjectPath) {
				var that = this;
				var oBundle = this.getView().getModel("i18n").getResourceBundle();
				var strDescriptions, strDescription, strBrands, strBrand;
				strDescriptions = "";
				strBrands = "";
				var strEntity = "/CRS_DataSet(CRSId=" + this.crsid + "m,Version=0m)/CRS_AttributeSet";

				var oModel = this.getOwnerComponent().getModel("rs");
				oModel.read(strEntity, {
					success: function(response) {
						var i;
						var strDelimiter;
						var nDelimiterLength;
						strDelimiter = ", ";
						nDelimiterLength = strDelimiter.length;

						for (i = 0; i < response.results.length; i++) {
							// 2 = TargetGroups
							if (response.results[i].ID_ATTRIB_GROUP === "2") {
								strDescription = response.results[i].ATTRIB_NAME;
								if (strDescription.length > 0) {
									strDescriptions = strDescriptions + strDescription + strDelimiter;
								}
							}
							// 1 = car brands
							if (response.results[i].ID_ATTRIB_GROUP === "1") {
								strBrand = response.results[i].ATTRIB_VALUE;
								if (!strBrands.includes(strBrand)) {
									strBrands = strBrands + strBrand + strDelimiter;
								}
							}

						}
						if (strDescriptions.endsWith(strDelimiter)) {
							strDescriptions = strDescriptions.substr(0, strDescriptions.length - nDelimiterLength);
						}
						if (strBrands.endsWith(strDelimiter)) {
							strBrands = strBrands.substr(0, strBrands.length - nDelimiterLength);
						}

						that.getView().byId("txtDesc").setText(oBundle.getText("textType.repair") + strDescriptions);
						that.getView().byId("txtBrands").setText(oBundle.getText("textBrands.repair") + strBrands);
					},
					error: function(oError) {
						var strMsg = oBundle.getText("ReadError", strEntity);
						sap.m.MessageToast.show(strMsg);
					},
					abort: function() {
						var strMsg = oBundle.getText("ReadFatalError", strEntity);
						sap.m.MessageToast.show(strMsg);
					}
				});
			}
			// End - Section for all private functions.
	});

});