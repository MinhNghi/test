sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"sap/m/MessageBox",
	"atudoboilerplate/controller/BaseCRSController"
], function(UIComponent, JSONModel, History, MessageBox, BaseCRSController, SystemInfoDialog) {
	"use strict";

	return BaseCRSController.extend("atudoboilerplate.controller.SplashScreen", {
		onInit: function() {
			UIComponent.getRouterFor(this).getRoute("SplashScreen").attachPatternMatched(this._onObjectMatched, this);
		},

		_onObjectMatched: function(oEvent) {
			this.lat = oEvent.getParameter("arguments").lat;
			this.lng = oEvent.getParameter("arguments").lng;
			// Set show/hide Home button
			this._showhideHomeButton();
		},

		onClose: function() {
			this.onLocatePress();
		},

		onGo: function() {
			this.onLocatePress();
		}
	});

});