sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/UIComponent",
	"openui5/googlemaps/MapUtils",
	"sap/ui/core/routing/History",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"google.maps",
	"atudoboilerplate/controller/BaseCRSController"
], function(Controller, UIComponent, util, History, Filter, FilterOperator, googlemaps, BaseCRSController) {
	"use strict";

	return BaseCRSController.extend("atudoboilerplate.controller.Karte", {
		onInit: function() {
			var oComponent = this.getOwnerComponent();
			this.oModel = oComponent.getModel("rs");
			UIComponent.getRouterFor(this).getRoute("Karte").attachPatternMatched(this._onObjectMatched, this);
		},

		onSearch: function(event) {
			var oMap = this.byId("mapMarker");
			var oLatLng = oMap.map.getCenter();
			var sLat = oLatLng.lat();
			var sLng = oLatLng.lng();
			this._displayMap(event, sLat, sLng);
		},

		onPressMarker: function(event) {
			var oSource = event.getSource();
			var oContext = oSource.getBindingContext();
			var sLat = oContext.getProperty("shopLat");
			var sLng = oContext.getProperty("shopLng");
			var sId = oContext.getProperty("id");
			if (sId !== "") {
				UIComponent.getRouterFor(this).navTo("RepairShopDetail", {
					lat: sLat,
					lng: sLng,
					Id: sId,
					Id_user: this.Id_user,
					Distance: 0
				});
			}
		},

		onAfterShow: function(event) {
			this._displayMap(event, this.lat, this.lng);
		},

		onDetail: function(element) {
			alert("Clicked");
		},

		_onObjectMatched: function(oEvent) {
			// Set all parameters of query to variables to use in next pages.
			var args = oEvent.getParameter("arguments");
			this.email = args.email;
			this.lng = args.lng;
			this.lat = args.lat;
			this.Id_user = args.Id_user;
			this._showhideHomeButton();
			//Disable button Karte
			this.getView().byId("btnMap").setEnabled(false);
			this.getView().addEventDelegate({
				onAfterShow: jQuery.proxy(function(evt) {
					this.onAfterShow(evt);
				}, this)
			});
		},

		_displayMap: function(event, sLat, sLng) {
			var boxList = [];
			var that = this;
			var aMarkerId = [];
			var markers = [];
			var aFilter = [];
			var oMarker = {};
			var oMap = this.byId("mapMarker");
			var sViewId = this.getView().getId();
			var sId;
			that.lat = sLat;
			that.lng = sLng;
			aFilter.push(new Filter("Longitude", FilterOperator.EQ, sLng));
			aFilter.push(new Filter("Latitude", FilterOperator.EQ, sLat));
			aFilter.push(new Filter("UserId", FilterOperator.EQ, this.Id_user));
			markers.push({
				id: "",
				lat: that.lat,
				lng: that.lng,
				shopInfo: "",
				shopLat: that.lat,
				shopLng: that.lng
			});
			sId = sViewId + "--marker-" + oMap.getId() + "-" + "0";
			aMarkerId.push({
				id: sId,
				favorite: ""
			});

			this.oModel.read("/CRS_FindSet", {
				filters: aFilter,
				success: function(oShopData, response) {
					var latlng = [
						new googlemaps.LatLng(that.lat, that.lng)
					];
					if (oShopData.results.length > 0) {
						for (var i = 0; i < oShopData.results.length; i++) {
							if (i < 3) {
								var k = i + 1;
								var sBoxId = "boxInfo" + k;
								var sTarget = that._getUrlDetail(oShopData.results[i]);
								latlng.push(new googlemaps.LatLng(oShopData.results[i].Latitude, oShopData.results[i].Longitude));
								var sImgScr,
									sInfoContent;
								if (oShopData.results[i].Favorite === true) {
									sImgScr = '<img width="15px" height="15px" src="img/NoText/Orange/ic_Favorit_24p_Orange.svg">';
									/*sInfoContent = '<div id="' + sBoxId + '">' + sImgScr + '<b><a href="' + sTarget + '">' + oShopData.results[i].Name +
										'</a></b><br/>' + oShopData.results[i].Street + ", " + oShopData.results[i].City + '</div>';*/
									sInfoContent ='<a href="' + sTarget + '"><div id="' + sBoxId + '">' + sImgScr + '<b>' + oShopData.results[i].Name +
										'</b><br/>' + oShopData.results[i].Street + ", " + oShopData.results[i].City + '</div></a>';
								} else {
									/*sInfoContent = '<div id="' + sBoxId + '"><b><a href="' + sTarget + '">' + oShopData.results[i].Name +
										'</a></b><br/>' + oShopData.results[i].Street + ", " + oShopData.results[i].City + '</div>';*/
									sInfoContent = '<a href="' + sTarget + '"><div id="' + sBoxId + '"><b>' + oShopData.results[i].Name +
										'</b><br/>' + oShopData.results[i].Street + ", " + oShopData.results[i].City + '</div></a>';
								}
								markers.push({
									id: oShopData.results[i].CRSId,
									lat: that.lat,
									lng: that.lng,
									shopInfo: sInfoContent,
									shopLat: oShopData.results[i].Latitude,
									shopLng: oShopData.results[i].Longitude,
									favorite: oShopData.results[i].Favorite
								});
								var iPos = i + 1;
								sId = sViewId + "--marker-" + oMap.getId() + "-" + iPos;
								aMarkerId.push({
									id: sId,
									shopInfo: sInfoContent
								});

							}
						}
					} else {
						markers.push({
							id: "",
							lat: that.lat,
							lng: that.lng,
							shopInfo: "",
							shopLat: "",
							shopLng: "",
							favorite: ""
						});
					}
					var oJsonModel = new sap.ui.model.json.JSONModel({
						markers: markers
					});
					oMap.setModel(oJsonModel);
					oJsonModel.refresh(true);

					for (var j = 0; j < aMarkerId.length; j++) {
						oMarker = sap.ui.getCore().byId(aMarkerId[j].id);
						if (oMarker.aListeners.length === 0) {
							oMarker.setMarker();
						}
						if (oMarker.aListeners.length !== 0) {
							if (j === 0) {
								var image = {
									url: "img/position_icon.svg",
									size: new googlemaps.Size(71, 71),
									origin: new googlemaps.Point(0, 0),
									anchor: new googlemaps.Point(0, 32),
									scaledSize: new googlemaps.Size(30, 30)
								};
								oMarker.setIcon(image);
								var oMarkerOptions = oMarker.getOptions();
								oMarkerOptions.optimized = false;
								oMarker.marker.setOptions(oMarkerOptions);
								oMarker.aListeners.forEach(function(t) {
									t.remove();
								});
							} else {
								oMarker.infoWindow.setContent(aMarkerId[j].shopInfo);
								oMarker.infoWindowOpen();
								oMarker.setVisible(false);

								var sLink = "boxInfo" + j;
								jQuery(that.createId(sLink)).on("click", that.onDetail.bind(that));
							}
						}
					}
					var latlngbounds = new googlemaps.LatLngBounds();
					for (var k = 0; k < latlng.length; k++) {
						latlngbounds.extend(latlng[k]);
					}
					oMap.map.fitBounds(latlngbounds);
					oMap.map.panToBounds(latlngbounds);

					oMap.addEventDelegate({
						onAfterRendering: function() {
							for (var j = 0; j < aMarkerId.length; j++) {
								oMarker = sap.ui.getCore().byId(aMarkerId[j].id);
								if (oMarker.aListeners.length !== 0) {
									if (j === 0) {
										var image = {
											url: "img/position_icon.svg",
											size: new googlemaps.Size(71, 71),
											origin: new googlemaps.Point(0, 0),
											anchor: new googlemaps.Point(0, 32),
											scaledSize: new googlemaps.Size(30, 30)
										};
										oMarker.setIcon(image);
										var oMarkerOptions = oMarker.getOptions();
										oMarkerOptions.optimized = false;
										oMarker.marker.setOptions(oMarkerOptions);
										oMarker.aListeners.forEach(function(t) {
											t.remove();
										});
									} else {
										oMarker.infoWindow.setContent(aMarkerId[j].shopInfo);
										oMarker.infoWindowOpen();
										oMarker.setVisible(false);
									}
								}
							}
							latlngbounds = new googlemaps.LatLngBounds();
							for (var k = 0; k < latlng.length; k++) {
								latlngbounds.extend(latlng[k]);
							}
							oMap.map.fitBounds(latlngbounds);
							oMap.map.panToBounds(latlngbounds);
						}
					}, this);
				},
				error: function(oError) {}
			});
		}
	});

});