sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"sap/m/MessageBox",
	"atudoboilerplate/controller/BaseCRSController",
	"atudoboilerplate/controller/SystemInfoDialog"
], function(UIComponent, JSONModel, History, MessageBox, BaseCRSController, SystemInfoDialog) {
	"use strict";

	return BaseCRSController.extend("atudoboilerplate.controller.Settings", {
		onInit: function() {
			this.SystemInfoDialog = new SystemInfoDialog();
			UIComponent.getRouterFor(this).getRoute("Settings").attachPatternMatched(this._onObjectMatched, this);
		},

		onAfterRendering: function() {
			var that = this;
			if (sap.ui.Device.system.desktop) {
				var start,
					longpress = 5000;
				this.byId("txtVersion").attachBrowserEvent("mousedown touchstart", function(evt) {
					start = new Date().getTime();
				});
				this.byId("txtVersion").attachBrowserEvent("mouseleave touchleave", function(evt) {
					start = 0;
				});
				this.byId("txtVersion").attachBrowserEvent("mouseup touchend", function(evt) {
					if (new Date().getTime() >= (start + longpress)) {
						that.SystemInfoDialog.open(that.getView());
					}
				});
			}

			if (sap.ui.Device.system.tablet || sap.ui.Device.system.phone) {
				$.event.special.tap.tapholdThreshold = 5000;
				this.byId("txtVersion").attachBrowserEvent("taphold", function(evt) {
					that.SystemInfoDialog.open(that.getView());
				});
			}

		},

		_onObjectMatched: function(oEvent) {
			var oGeneralModel = sap.ui.getCore().getModel("general");
			var oGeneralData = oGeneralModel.getData();
			this.lat = oEvent.getParameter("arguments").lat;
			this.lng = oEvent.getParameter("arguments").lng;
			this.email = oGeneralData.email;
			this.Id_user = oGeneralData.id_user;
			this.identifyId = oGeneralData.identifyId;
			this._showhideHomeButton();
			var oSettingModel = new sap.ui.model.json.JSONModel();
			oSettingModel.setData({
				Type: "",
				Path: "",
				Descending: ""
			});
			sap.ui.getCore().setModel(oSettingModel, "settings");

			//Add dummy box
			if (sap.ui.Device.system.phone && sap.ui.Device.browser.mobile) {
				this._addDummyBox();
			}
		},

		onClose: function() {
			var oSettingModel = sap.ui.getCore().getModel("settings");
			var oSettingData = oSettingModel.getData();
			var oRating = this.getView().byId("rbRating");
			var oDistance = this.getView().byId("rbDistance");
			var oAll = this.getView().byId("rbAll");
			var oFree = this.getView().byId("rbFree");
			var oContract = this.getView().byId("rbContract");
			if (oRating.getSelected() === true) {
				oSettingData.Path = "Rating";
				oSettingData.Descending = true;
			} else if (oDistance.getSelected() === true) {
				oSettingData.Path = "Distance";
				oSettingData.Descending = false;
			}

			if (oAll.getSelected() === true) {
				oSettingData.Type = null;
			} else if (oFree.getSelected() === true) {
				oSettingData.Type = "free";
			} else if (oContract.getSelected() === true) {
				oSettingData.Type = "contract";
			}
			oSettingModel.setData(oSettingData);
			var oHistory = History.getInstance();
			var oPreviousHash = oHistory.getPreviousHash();
			if (oPreviousHash.includes("LocateRepairShops")) {
				this.onLocatePress();
			} else if (oPreviousHash.includes("FavoriteRepairShops")) {
				this.onFavoritePress();
			} else {
				window.history.go(-1);
			}

		},

		onPanelSort: function(event) {
			var oPanel = this.getView().byId("panelSort");
			var oBtnSortPanel = this.getView().byId("btnSortPanel");
			var isVisible = oPanel.getVisible();
			if (isVisible === true) {
				oPanel.setVisible(false);
				oBtnSortPanel.setIcon("sap-icon://navigation-up-arrow");
			} else {
				oPanel.setVisible(true);
				oBtnSortPanel.setIcon("sap-icon://navigation-down-arrow");
			}
		},

		onPanelFilter: function(event) {
			var oPanel = this.getView().byId("panelFilter");
			var oBtnFilterPanel = this.getView().byId("btnFilterPanel");
			var isVisible = oPanel.getVisible();
			if (isVisible === true) {
				oPanel.setVisible(false);
				oBtnFilterPanel.setIcon("sap-icon://navigation-up-arrow");
			} else {
				oPanel.setVisible(true);
				oBtnFilterPanel.setIcon("sap-icon://navigation-down-arrow");
			}
		},

		onPanelCreate: function(event) {
			var oPanel = this.getView().byId("panelCreate");
			var oBtnCreatePanel = this.getView().byId("btnCreatePanel");
			var isVisible = oPanel.getVisible();
			if (isVisible === true) {
				oPanel.setVisible(false);
				oBtnCreatePanel.setIcon("sap-icon://navigation-up-arrow");
			} else {
				oPanel.setVisible(true);
				oBtnCreatePanel.setIcon("sap-icon://navigation-down-arrow");
			}
		},

		onPanelSystem: function(event) {
			var oPanel = this.getView().byId("panelSystem");
			var oBtnFilterPanel = this.getView().byId("btnSystemPanel");
			var isVisible = oPanel.getVisible();
			if (isVisible === true) {
				oPanel.setVisible(false);
				oBtnFilterPanel.setIcon("sap-icon://navigation-up-arrow");
			} else {
				oPanel.setVisible(true);
				oBtnFilterPanel.setIcon("sap-icon://navigation-down-arrow");
			}
		},

		onPanelSplashScreen: function(event) {
			var oPanel = this.getView().byId("panelSplashScreen");
			var oBtnFilterPanel = this.getView().byId("btnSplashScreenPanel");
			var isVisible = oPanel.getVisible();
			if (isVisible === true) {
				oPanel.setVisible(false);
				oBtnFilterPanel.setIcon("sap-icon://navigation-up-arrow");
			} else {
				oPanel.setVisible(true);
				oBtnFilterPanel.setIcon("sap-icon://navigation-down-arrow");
			}
		},

		onPressSplashScreen: function(event) {
			UIComponent.getRouterFor(this).navTo("SplashScreen", {
				lat: this.lat,
				lng: this.lng
			});
		},

		onCreatePress: function(event) {
			var sName = this.byId("txtName").getValue();
			var sStreet = this.byId("txtStreet").getValue();
			var sCity = this.byId("txtCity").getValue();
			var sZipCode = this.byId("txtZipCode").getValue();
			var sPhone = this.byId("txtPhone").getValue();
			var sEmail = this.byId("txtEmail").getValue();
			var sWebsite = this.byId("txtWebsite").getValue();
			var oProperties = {
				Name: sName,
				Street: sStreet,
				PostalCode: sZipCode,
				Country: "DE",
				City: sCity,
				FixedPhone: sPhone,
				EMail: sEmail,
				Web: sWebsite
			};
			// create new entry in the model
			this._oContext = this.getOwnerComponent().getModel("rs").createEntry("/CRS_DataSet", {
				properties: oProperties,
				success: this._onCreateSuccess(oProperties)
			});

			this.getOwnerComponent().getModel("rs").submitChanges();
		},

		onSorting: function() {
			var oSettingModel = sap.ui.getCore().getModel("settings");
			var oSettingData = oSettingModel.getData();
			var oRating = this.getView().byId("rbRating");
			var oDistance = this.getView().byId("rbDistance");
			if (oRating.getSelected() === true) {
				oSettingData.Path = "Rating";
				oSettingData.Descending = true;
			} else if (oDistance.getSelected() === true) {
				oSettingData.Path = "Distance";
				oSettingData.Descending = false;
			}
			oSettingModel.setData(oSettingData);
		},

		onFiltering: function() {
			var oSettingModel = sap.ui.getCore().getModel("settings");
			var oSettingData = oSettingModel.getData();
			var oAll = this.getView().byId("rbAll");
			var oFree = this.getView().byId("rbFree");
			var oContract = this.getView().byId("rbContract");
			if (oAll.getSelected() === true) {
				oSettingData.Type = null;
			} else if (oFree.getSelected() === true) {
				oSettingData.Type = "free";
			} else if (oContract.getSelected() === true) {
				oSettingData.Type = "contract";
			}
			oSettingModel.setData(oSettingData);
		},

		_onCreateSuccess: function(oProperties) {
			var that = this;
			var oStyle = !!this.getView().$().closest(".sapUiSizeCompact").length;
			MessageBox.success("Danke! Wir übernehmen Ihren Eintrag nach Prüfung", {
				styleClass: oStyle ? "sapUiSizeCompact" : "",
				actions: [MessageBox.Action.OK],
				onClose: function(oAction) {
					if (oAction === MessageBox.Action.OK) {
						that.byId("txtName").setValue("");
						that.byId("txtStreet").setValue("");
						that.byId("txtCity").setValue("");
						that.byId("txtZipCode").setValue("");
						that.byId("txtPhone").setValue("");
						that.byId("txtEmail").setValue("");
						that.byId("txtWebsite").setValue("");
					}
				}
			});
		},

		_addDummyBox: function() {
			var oBoxDummy = this.byId("boxDummy");
			var oNameText = this.byId("txtName");
			var oStreetText = this.byId("txtStreet");
			var oZipText = this.byId("txtZipCode");
			var oCityText = this.byId("txtCity");
			var oPhoneText = this.byId("txtPhone");
			var oEmailText = this.byId("txtEmail");
			var oWebText = this.byId("txtWebsite");

			oNameText.addEventDelegate({
				onfocusin: function() {
					oBoxDummy.setVisible(true);
				},
				onfocusout: function() {
					oBoxDummy.setVisible(false);
				}
			});

			oStreetText.addEventDelegate({
				onfocusin: function() {
					oBoxDummy.setVisible(true);
				},
				onfocusout: function() {
					oBoxDummy.setVisible(false);
				}
			});

			oZipText.addEventDelegate({
				onfocusin: function() {
					oBoxDummy.setVisible(true);
				},
				onfocusout: function() {
					oBoxDummy.setVisible(false);
				}
			});

			oCityText.addEventDelegate({
				onfocusin: function() {
					oBoxDummy.setVisible(true);
				},
				onfocusout: function() {
					oBoxDummy.setVisible(false);
				}
			});

			oPhoneText.addEventDelegate({
				onfocusin: function() {
					oBoxDummy.setVisible(true);
				},
				onfocusout: function() {
					oBoxDummy.setVisible(false);
				}
			});

			oEmailText.addEventDelegate({
				onfocusin: function() {
					oBoxDummy.setVisible(true);
				},
				onfocusout: function() {
					oBoxDummy.setVisible(false);
				}
			});

			oWebText.addEventDelegate({
				onfocusin: function() {
					oBoxDummy.setVisible(true);
				},
				onfocusout: function() {
					oBoxDummy.setVisible(false);
				}
			});

		}
	});

});