sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/UIComponent",
	"sap/ui/core/routing/History"
], function(Controller, UIComponent, History) {
	"use strict";

	return Controller.extend("atudoboilerplate.controller.BaseCRSController", {
		getRouter: function() {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},
		setModel: function(oModel, sName) {
			return this.getView().setModel(oModel, sName);
		},
		getModel: function(sName) {
			return this.getView().getModel(sName);
		},
		getResourceBundle: function() {
			return this.getOwnerComponent().getModel("i18n").getResourceBundle();
		},
		getGeneralData: function() {
			return sap.ui.getCore().getModel("general").getData();
		},

		// Navigate to Home page
		onHomePress: function() {
			var oModel = this.getView().getModel("rs");
			oModel.removeData();
			this.getView().unbindElement("rs");
			sap.ui.getCore().setModel(null, "settings");
			sap.ui.getCore().setModel(null, "general");

			UIComponent.getRouterFor(this).navTo("Home");
		},

		// Navigate to CRS list page
		onLocatePress: function() {
			var oGeneralData = this.getGeneralData();
			UIComponent.getRouterFor(this).navTo("LocateRepairShops", {
				email: oGeneralData.email,
				token: oGeneralData.token,
				lat: this.lat,
				lng: this.lng,
				heading: 1,
				os: "android",
				atuid: oGeneralData.identifyId
			});
		},

		// Navigate to Appointment page
		onAppointmentPress: function(event) {
			UIComponent.getRouterFor(this).navTo("RepairShopAppointment", {
				lat: this.lat,
				lng: this.lng,
				Id_user: this.Id_user,
				email: this.email
			});
		},

		// Navigate to Favorite page
		onFavoritePress: function(event) {
			UIComponent.getRouterFor(this).navTo("FavoriteRepairShops", {
				email: this.email,
				lat: this.lat,
				lng: this.lng,
				Id_user: this.Id_user
			});
		},

		// Navigate to Map page
		onKartePress: function(event) {
			UIComponent.getRouterFor(this).navTo("Karte", {
				email: this.email,
				lat: this.lat,
				lng: this.lng,
				Id_user: this.Id_user
			});
		},

		// Navigate to Detail page
		onNavDetail: function() {
			UIComponent.getRouterFor(this).navTo("RepairShopDetail", {
				lat: this.lat,
				lng: this.lng,
				Id: this.CRSId,
				Id_user: this.Id_user,
				Distance: this.distance,
				email: this.email
			});
		},

		// Set CRS icon for Type and Favorite in list
		_setIcon: function() {
			var oList = this.getView().byId("repairShopList");
			var oContext = oList.getBinding("items").getCurrentContexts();
			var sListId = oList.getId();
			var sViewId = this.getView().getId();
			if (oContext.length > 0) {
				var sFavoriteIconId,
					sTypeIconId;
				var oImgFavo,
					oImgType;

				for (var i = 0; i < oContext.length; i++) {
					var sPath = oContext[i].getPath();
					var oData = oList.getModel().getProperty(sPath);
					// Set Like icon on list
					sFavoriteIconId = sViewId + "--imgFavorite-" + sListId + "-" + i;
					oImgFavo = sap.ui.getCore().byId(sFavoriteIconId);
					if (typeof oImgFavo !== "undefined" && oData !== undefined) {
						if (oData.Favorite === true) {
							oImgFavo.setSrc("img/NoText/Orange/ic_Favorit_24p_Orange.svg");
						} else {
							oImgFavo.setVisible(false);
						}
					}

					// Set Type icon on list
					sTypeIconId = sViewId + "--imgType-" + sListId + "-" + i;
					oImgType = sap.ui.getCore().byId(sTypeIconId);
					if (typeof oImgType !== "undefined" && oData !== undefined) {
						switch (oData.Type) {
							case "contract":
								oImgType.setSrc("img/Vertragswerkstatt.svg");
								break;
							case "free":
								oImgType.setSrc("img/Freie_Werkstatt.svg");
								break;
							default:
								oImgType.setSrc("img/Freie_Werkstatt.svg");
								break;
						}
					}
				}
			} else {
				return;
			}
		},

		// Set Like/Dislike (start icon) in Detail and Call page.
		_setLikeDislike: function(Type_Favo) {
			switch (Type_Favo) {
				case "F":
					this.getView().byId("imgLike").setSrc("img/NoText/Orange/ic_Favorit_24p_Orange.svg");
					break;
				case "A":
					this.getView().byId("imgLike").setSrc("img/NoText/Weiss/star.png");
					break;
				case "":
					this.getView().byId("imgLike").setSrc("img/NoText/Weiss/star.png");
					break;
				case " ":
					this.getView().byId("imgLike").setSrc("img/NoText/Weiss/star.png");
					break;
			}
		},

		// Create a CRS Log with type
		createCRSLog: function(oProperties) {
			var that = this;
			var oModel = this.getView().getModel("rs");
			oModel.createEntry("/CRS_LogSet", {
				properties: oProperties,
				success: function() {
					that.onCRSLogSuccess(oProperties);
				}
			});
			oModel.submitChanges();
		},
		onCRSLogSuccess: function(oProperties) {
			// If CRS Log is created with type "r - recall", show a message to user.
			if (oProperties.Type === "r") {
				var oView = this.getView();
				oView.byId("txtTelephone").setValue("");
				oView.byId("txtVorname").setValue("");
				oView.byId("txtName").setValue("");
				oView.byId("cbTime").setSelectedKey("1");
				UIComponent.getRouterFor(this).navTo("Message", {
					action: "ReCall",
					crsid: this.crsid
				});
			}
		},

		_getUrlDetail: function(oShopData) {
			var sHref = window.location.href;
			var sURL;
			var sTarget;
			var oParams;
			var sHost = sHref.substring(0, sHref.lastIndexOf('#') + 1);
			var oRouter = UIComponent.getRouterFor(this).getRoute("RepairShopDetail");
			oParams = {
				lat: this.lat,
				lng: this.lng,
				Id: oShopData.CRSId,
				Id_user: oShopData.UserId,
				Distance: oShopData.Distance,
				email: this.email
			};
			sURL = oRouter.getURL(oParams);
			sTarget = sHost + sURL;
			return sTarget;

		},

		_showhideHomeButton: function() {
			jQuery.sap.require("jquery.sap.storage");
			var oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.local);
			var bDebug = oStorage.get("debugFlag");
			if (bDebug === true) {
				this.getView().byId("btnHome").setVisible(true);
			} else {
				this.getView().byId("btnHome").setVisible(false);
			}
		}

	});

});