sap.ui.define([
	"atudoboilerplate/controller/MyController",
	"sap/ui/core/UIComponent",
	"sap/m/MessageBox",
	"atudoboilerplate/controller/BaseCRSController",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function(MyController, UIComponent, MessageBox, BaseCRSController, Filter, FilterOperator) {
	"use strict";

	return BaseCRSController.extend("atudoboilerplate.controller.ReviewRepairShop", {
		onInit: function() {
			// Register to the ChangeRepairShop route matched
			this.getRouter().getRoute("ReviewRepairShop").attachPatternMatched(this._onObjectMatched, this);
		},

		onClose: function(event) {
			var oGeneralModel = sap.ui.getCore().getModel("general");
			var oGeneralData = oGeneralModel.getData();
			UIComponent.getRouterFor(this).navTo("RepairShopDetail", {
				lat: oGeneralData.lat,
				lng: oGeneralData.lng,
				Id: this.crsid,
				Id_user: oGeneralData.id_user,
				Distance: oGeneralData.distance,
				email: oGeneralData.email
			});
		},
		
		// Event of the GUI when user click button to submit a new review
		onSubmitReview: function() {
			var that = this;
			var aFilter = [];
			var oFilter1 = new Filter("CRSId", FilterOperator.EQ, this.crsid);
			var oFilter2 = new Filter("Id_User", FilterOperator.EQ, this.UserId);
			var oFilter3 = new Filter("Status", FilterOperator.EQ, "o");
			var oFilter = new Filter({
				filters: [
					oFilter1,
					oFilter2,
					oFilter3
				],
				and: true
			});
			aFilter.push(oFilter);
			var sSubject = this.getView().byId("txtSubject").getValue();
			var sComment = this.getView().byId("txtComment").getValue();
			var oComboRate = this.getView().byId("cbRate");
			var sValueRate = oComboRate.getSelectedKey();
			if (sValueRate === undefined || sValueRate === "") {
				oComboRate.focus();
				var oI18n = this.getView().getModel("i18n").getResourceBundle();
				var sMissingReview = oI18n.getText("textMissingReview.review");
				MessageBox.error(sMissingReview);
			} else {
				var oNewReview = {
					CRSId: that.crsid,
					Review_Value: sValueRate,
					Id_User: that.UserId,
					Subject: sSubject,
					Review_Text: sComment
				};

				var oModel = this.getModel("rs");
				oModel.createEntry("/CRS_ReviewSet", {
					properties: oNewReview,
					success: function() {
						that.getView().byId("txtSubject").setValue("");
						that.getView().byId("txtComment").setValue("");
						that.getView().byId("cbRate").setSelectedKey(null);
						UIComponent.getRouterFor(that).navTo("Message", {
							action: "Review",
							crsid: that.crsid
						});
					},
					error: function() {
						MessageBox.show("Create review not successfully!");
					}
				});
				oModel.submitChanges();
			}
		},
		
		// Event of the GUI reaction when user is typing comment
		onTextAreaChange: function(event) {
			//Get max length of Text area
			var oBundle = this.getModel("i18n").getResourceBundle();
			var iMaxLength = this.getView().byId("txtComment").getMaxLength();

			//Get value of comment and count the characters
			var sText = event.getParameter("value");
			var iCurrentLength = sText.length;

			//Update the remaining characters in text area
			if (iCurrentLength <= iMaxLength) {
				var iRemaining = iMaxLength - iCurrentLength;
				var sLabel = oBundle.getText("textReview.review", [iRemaining]);
				this.getView().byId("labelcomment").setText(sLabel);
			}

		},

		_onObjectMatched: function(oEvent) {
			this.UserId = oEvent.getParameter("arguments").UserId;
			this.crsid = oEvent.getParameter("arguments").CRSId;

			//Get max length of Text area
			var oBundle = this.getModel("i18n").getResourceBundle();
			var iMaxLength = this.getView().byId("txtComment").getMaxLength();
			var iCurrentLength = this.getView().byId("txtComment").getValue().length;

			//Update the remaining characters in text area
			if (iCurrentLength <= iMaxLength) {
				var iRemaining = iMaxLength - iCurrentLength;
				var sLabel = oBundle.getText("textReview.review", [iRemaining]);
				this.getView().byId("labelcomment").setText(sLabel);
			}
			this._showhideHomeButton();

			//Add dummy box
			if (sap.ui.Device.system.phone && sap.ui.Device.browser.mobile) {
				this._addDummyBox();
			}
		},

		_addDummyBox: function() {
			var oBoxDummy = this.byId("boxDummy");
			var oRate = this.byId("cbRate");
			var oSubjectText = this.byId("txtSubject");
			var oCommentText = this.byId("txtComment");

			oRate.addEventDelegate({
				onfocusin: function() {
					oBoxDummy.setVisible(true);
				},
				onfocusout: function() {
					oBoxDummy.setVisible(false);
				}
			});

			oSubjectText.addEventDelegate({
				onfocusin: function() {
					oBoxDummy.setVisible(true);
				},
				onfocusout: function() {
					oBoxDummy.setVisible(false);
				}
			});

			oCommentText.addEventDelegate({
				onfocusin: function() {
					oBoxDummy.setVisible(true);
				},
				onfocusout: function() {
					oBoxDummy.setVisible(false);
				}
			});
		}

	});

});