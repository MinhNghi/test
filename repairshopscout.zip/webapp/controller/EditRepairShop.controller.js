sap.ui.define([
	"atudoboilerplate/controller/MyController",
	"sap/ui/core/UIComponent",
	"sap/ui/core/routing/History",
	"atudoboilerplate/model/formatter",
	"sap/m/MessageBox",
	"jquery.sap.global",
	"sap/ui/model/SimpleType",
	"sap/ui/model/ValidateException",
	"atudoboilerplate/controller/BaseCRSController"
], function(MyController, UIComponent, History, formatter, MessageBox, jQuery, SimpleType, ValidateException, BaseCRSController) {
	"use strict";

	return BaseCRSController.extend("atudoboilerplate.controller.EditRepairShop", {
		formatter: formatter,
		onInit: function() {
			// Register to the ChangeRepairShop route matched
			this.getRouter().getRoute("EditRepairShop").attachPatternMatched(this._onObjectMatched, this);
		},

		onExistingShop: function(event) {
			var oRbEdit = this.getView().byId("rbEdit");
			var oRbNotEdit = this.getView().byId("rbNotEdit");
			if (oRbEdit.getSelected() === true) {
				this.NotExistingShop = false;
				this._setEditable(true);
			}
			if (oRbNotEdit.getSelected() === true) {
				this.NotExistingShop = true;
				this._setEditable(false);
			}
		},

		onClose: function(event) {
			var oContext = event.getSource().getBindingContext("rs");
			var sCRSId = oContext.getProperty("CRSId");
			var oGeneralModel = sap.ui.getCore().getModel("general");
			var oGeneralData = oGeneralModel.getData();
			this.getView().unbindElement("rs");
			UIComponent.getRouterFor(this).navTo("RepairShopDetail", {
				lat: oGeneralData.lat,
				lng: oGeneralData.lng,
				Id: sCRSId,
				Id_user: oGeneralData.id_user,
				Distance: oGeneralData.distance,
				email: oGeneralData.email
			});
		},

		_onObjectMatched: function(oEvent) {
			this.getView().bindElement({
				path: "/" + oEvent.getParameter("arguments").shopPath,
				model: "rs"
			});
			// attach handlers for validation errors
			sap.ui.getCore().attachValidationError(function(evt) {
				var control = evt.getParameter("element");
				if (control && control.setValueState) {
					control.setValueState("Error");
				}
			});
			sap.ui.getCore().attachValidationSuccess(function(evt) {
				var control = evt.getParameter("element");
				if (control && control.setValueState) {
					control.setValueState("None");
				}
			});
			this.lat = oEvent.getParameter("arguments").lat;
			this.lng = oEvent.getParameter("arguments").lng;
			this.NotExistingShop = false;
			this._showhideHomeButton();
			
			//Add dummy box
			if (sap.ui.Device.system.phone && sap.ui.Device.browser.mobile) {
				this._addDummyBox();
			}
		},

		handleUpdateChange: function(event) {
			var that = this;
			var oView = this.getView();
			var oSource = event.getSource();
			var oContext = oSource.getBindingContext("rs");
			var sPath = oContext.getPath();
			var oModel = oContext.getModel();
			var oData = oContext.getObject();
			var sCRSId = oContext.getProperty("CRSId");
			var canUpdate = true;
			//Collect input controls value
			//Check valid value for input
			var inputs = [
				oView.byId("nameInput"),
				oView.byId("streetInput"),
				oView.byId("zipInput"),
				oView.byId("cityInput"),
				oView.byId("emailInput")
			];

			jQuery.each(inputs, function(i, input) {
				if (!input.getValue() && input.getValue() !== "") {
					input.setValueState("Error");
				}
			});

			jQuery.each(inputs, function(i, input) {
				if ("Error" === input.getValueState()) {
					canUpdate = false;
					return false;
				}
			});

			// output result
			if (canUpdate) {
				//get new values and update data into backend
				oData.Name = oView.byId("nameInput").getValue();
				oData.Street = oView.byId("streetInput").getValue();
				oData.PostalCode = oView.byId("zipInput").getValue();
				oData.City = oView.byId("cityInput").getValue();
				oData.FixedPhone = oView.byId("phoneInput").getValue();
				oData.EMail = oView.byId("emailInput").getValue();
				oData.Web = oView.byId("webInput").getValue();

				if (this.NotExistingShop === true) {
					// Set Address of shop to empty and change name to n/a
					oData.Name = "n/a";
					oData.Street = "";
					oData.PostalCode = "";
					oData.City = "";
				}

				oModel.update(sPath, oData, {
					success: function() {
						oModel.refresh(true);
						UIComponent.getRouterFor(that).navTo("Message", {
							action: "EditShop",
							crsid: sCRSId
						});
					},
					error: function() {
						jQuery.sap.require("sap.m.MessageBox");
						sap.m.MessageBox.error("Fehler beim Update!");
					}

				});

			} else {

				jQuery.sap.require("sap.m.MessageBox");
				sap.m.MessageBox.error("Please, complete your input first!");
			}

		},

		_typeEmail: SimpleType.extend("email", {
			formatValue: function(oValue) {
				return oValue;
			},
			parseValue: function(oValue) {
				//parsing step takes place before validating step, value can be altered
				return oValue;
			},
			validateValue: function(oValue) {
				// The following Regex is NOT a completely correct one and only used for demonstration purposes.
				// RFC 5322 cannot even checked by a Regex and the Regex for RFC 822 is very long and complex.
				var mailregex = /^\w+[\w-+\.]*\@\w+([-\.]\w+)*\.[a-zA-Z]{2,}$/;
				if (!oValue.match(mailregex) & oValue !== "") {
					throw new ValidateException("'" + oValue + "' is not a valid email address");
				}
			}
		}),

		_setEditable: function(bEditable) {
			var oView = this.getView();
			oView.byId("nameInput").setEditable(bEditable);
			oView.byId("streetInput").setEditable(bEditable);
			oView.byId("zipInput").setEditable(bEditable);
			oView.byId("cityInput").setEditable(bEditable);
			oView.byId("phoneInput").setEditable(bEditable);
			oView.byId("emailInput").setEditable(bEditable);
			oView.byId("webInput").setEditable(bEditable);

			if (bEditable === true) {
				oView.byId("nameInput").removeStyleClass("myNotInput");
				oView.byId("nameInput").addStyleClass("myInput");
				oView.byId("streetInput").removeStyleClass("myNotInput");
				oView.byId("streetInput").addStyleClass("myInput");
				oView.byId("zipInput").removeStyleClass("myNotInput");
				oView.byId("zipInput").addStyleClass("myInput");
				oView.byId("cityInput").removeStyleClass("myNotInput");
				oView.byId("cityInput").addStyleClass("myInput");
				oView.byId("phoneInput").removeStyleClass("myNotInput");
				oView.byId("phoneInput").addStyleClass("myInput");
				oView.byId("emailInput").removeStyleClass("myNotInput");
				oView.byId("emailInput").addStyleClass("myInput");
				oView.byId("webInput").removeStyleClass("myNotInput");
				oView.byId("webInput").addStyleClass("myInput");
			} else {
				oView.byId("nameInput").removeStyleClass("myInput");
				oView.byId("nameInput").addStyleClass("myNotInput");
				oView.byId("streetInput").removeStyleClass("myInput");
				oView.byId("streetInput").addStyleClass("myNotInput");
				oView.byId("zipInput").removeStyleClass("myInput");
				oView.byId("zipInput").addStyleClass("myNotInput");
				oView.byId("cityInput").removeStyleClass("myInput");
				oView.byId("cityInput").addStyleClass("myNotInput");
				oView.byId("phoneInput").removeStyleClass("myInput");
				oView.byId("phoneInput").addStyleClass("myNotInput");
				oView.byId("emailInput").removeStyleClass("myInput");
				oView.byId("emailInput").addStyleClass("myNotInput");
				oView.byId("webInput").removeStyleClass("myInput");
				oView.byId("webInput").addStyleClass("myNotInput");
			}
		},

		_addDummyBox: function() {
			var oBoxDummy = this.byId("boxDummy");
			var oNameText = this.byId("nameInput");
			var oStreetText = this.byId("streetInput");
			var oZipText = this.byId("zipInput");
			var oCityText = this.byId("cityInput");
			var oPhoneText = this.byId("phoneInput");
			var oEmailText = this.byId("emailInput");
			var oWebText = this.byId("webInput");

			oNameText.addEventDelegate({
				onfocusin: function() {
					oBoxDummy.setVisible(true);
				},
				onfocusout: function() {
					oBoxDummy.setVisible(false);
				}
			});

			oStreetText.addEventDelegate({
				onfocusin: function() {
					oBoxDummy.setVisible(true);
				},
				onfocusout: function() {
					oBoxDummy.setVisible(false);
				}
			});

			oZipText.addEventDelegate({
				onfocusin: function() {
					oBoxDummy.setVisible(true);
				},
				onfocusout: function() {
					oBoxDummy.setVisible(false);
				}
			});

			oCityText.addEventDelegate({
				onfocusin: function() {
					oBoxDummy.setVisible(true);
				},
				onfocusout: function() {
					oBoxDummy.setVisible(false);
				}
			});

			oPhoneText.addEventDelegate({
				onfocusin: function() {
					oBoxDummy.setVisible(true);
				},
				onfocusout: function() {
					oBoxDummy.setVisible(false);
				}
			});

			oEmailText.addEventDelegate({
				onfocusin: function() {
					oBoxDummy.setVisible(true);
				},
				onfocusout: function() {
					oBoxDummy.setVisible(false);
				}
			});

			oWebText.addEventDelegate({
				onfocusin: function() {
					oBoxDummy.setVisible(true);
				},
				onfocusout: function() {
					oBoxDummy.setVisible(false);
				}
			});

		}

	});

});